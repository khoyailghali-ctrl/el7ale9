@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0update-railway.ps1"
pause
