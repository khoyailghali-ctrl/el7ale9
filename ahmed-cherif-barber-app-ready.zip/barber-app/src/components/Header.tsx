"use client";

import Link from "next/link";
import { useLang } from "./LanguageProvider";
import { LanguageSwitcher } from "./LanguageSwitcher";
import { OpenStatusBadge } from "./OpenStatusBadge";
import { Logo } from "./Logo";
import type { PublicSettings } from "@/lib/settings-client";

export function Header({ settings }: { settings: PublicSettings }) {
  const { t } = useLang();
  void settings; // business name is already part of the logo artwork

  return (
    <header
      className="sticky top-0 z-50 backdrop-blur-md border-b"
      style={{ background: "rgba(246,241,231,0.9)", borderColor: "var(--coffee-light)" }}
    >
      <div className="max-w-6xl mx-auto px-5 sm:px-8 h-20 flex items-center justify-between gap-4">
        <Link href="/" className="flex items-center shrink-0">
          <Logo size={52} />
        </Link>

        <nav className="hidden md:flex items-center gap-7 text-sm font-medium" style={{ color: "var(--ink-soft)" }}>
          <a href="#services" className="hover:opacity-70 transition-opacity">
            {t("nav_services")}
          </a>
          <Link href="/my-appointments" className="hover:opacity-70 transition-opacity">
            {t("nav_my_appointments")}
          </Link>
          <a href="#contact" className="hover:opacity-70 transition-opacity">
            {t("nav_contact")}
          </a>
        </nav>

        <div className="flex items-center gap-3">
          <div className="hidden sm:block">
            <OpenStatusBadge />
          </div>
          <LanguageSwitcher />
          <Link
            href="/book"
            className="hidden sm:inline-flex items-center rounded-full px-4 py-2 text-sm font-semibold text-white transition-transform hover:scale-[1.03]"
            style={{ background: "var(--coffee)" }}
          >
            {t("nav_book")}
          </Link>
        </div>
      </div>
    </header>
  );
}
