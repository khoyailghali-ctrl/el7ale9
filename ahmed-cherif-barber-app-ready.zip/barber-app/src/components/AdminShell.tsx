"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { Logo } from "./Logo";

const NAV = [
  { href: "/admin", label: "Dashboard", icon: "🏠" },
  { href: "/admin/appointments", label: "Appointments", icon: "📋" },
  { href: "/admin/calendar", label: "Calendar", icon: "📅" },
  { href: "/admin/customers", label: "Customers", icon: "👥" },
  { href: "/admin/services", label: "Services", icon: "✂️" },
  { href: "/admin/business-hours", label: "Business Hours", icon: "🕐" },
  { href: "/admin/closures", label: "Closures", icon: "🚫" },
  { href: "/admin/announcements", label: "Announcements", icon: "📢" },
  { href: "/admin/revenue", label: "Revenue", icon: "💰" },
  { href: "/admin/settings", label: "Settings", icon: "⚙️" },
  { href: "/admin/profile", label: "Profile", icon: "👤" },
];

export function AdminShell({
  adminName,
  children,
}: {
  adminName: string;
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [shopOpen, setShopOpen] = useState<boolean | null>(null);
  const [toggling, setToggling] = useState(false);

  useEffect(() => {
    fetch("/api/shop-status")
      .then((r) => r.json())
      .then((d) => setShopOpen(Boolean(d.open)))
      .catch(() => {});
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  const toggleShop = async () => {
    if (shopOpen === null) return;
    setToggling(true);
    try {
      const res = await fetch("/api/shop-status", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ open: !shopOpen }),
      });
      const data = await res.json();
      if (res.ok) setShopOpen(data.open);
    } finally {
      setToggling(false);
    }
  };

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/admin/login");
    router.refresh();
  };

  return (
    <div className="min-h-screen flex" style={{ background: "var(--paper-warm)" }}>
      {/* mobile top bar */}
      <div
        className="md:hidden fixed top-0 inset-x-0 z-40 flex items-center justify-between px-4 h-14 border-b"
        style={{ background: "var(--ink)", borderColor: "var(--coffee-dark)" }}
      >
        <button
          onClick={() => setOpen(!open)}
          className="text-[var(--paper)] text-xl px-2 cursor-pointer"
          aria-label="Toggle menu"
        >
          ☰
        </button>
        <div className="flex items-center gap-2 text-[var(--paper)]">
          <Logo size={28} invert />
          <span className="text-sm font-medium">Admin</span>
        </div>
        <div className="w-8" />
      </div>

      {/* sidebar */}
      <aside
        className={`fixed md:sticky top-0 z-30 h-screen w-64 shrink-0 flex flex-col transition-transform md:translate-x-0
          ${open ? "translate-x-0" : "-translate-x-full"} md:pt-0 pt-14`}
        style={{ background: "var(--ink)" }}
      >
        <div className="hidden md:flex items-center gap-3 px-6 h-20">
          <Logo size={36} invert />
          <span className="text-[var(--paper)] font-display text-lg">Admin</span>
        </div>
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1 scrollbar-thin">
          {NAV.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors"
                style={{
                  background: active ? "var(--coffee)" : "transparent",
                  color: active ? "white" : "rgba(246,241,231,0.75)",
                }}
              >
                <span>{item.icon}</span>
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="p-3 border-t" style={{ borderColor: "rgba(246,241,231,0.1)" }}>
          <button
            onClick={toggleShop}
            disabled={shopOpen === null || toggling}
            className="w-full flex items-center justify-between rounded-lg px-3 py-2.5 text-sm font-semibold mb-2 cursor-pointer disabled:opacity-50"
            style={{
              background: shopOpen ? "rgba(63,107,74,0.2)" : "rgba(165,67,58,0.2)",
              color: shopOpen ? "#8fd6a0" : "#e79a92",
            }}
          >
            <span>{shopOpen ? "🟢 Shop Open" : "🔴 Shop Closed"}</span>
            <span className="text-xs opacity-70">{toggling ? "…" : "toggle"}</span>
          </button>
          <div className="text-xs text-[var(--paper)] opacity-50 px-3 mb-2 truncate">{adminName}</div>
          <button
            onClick={logout}
            className="w-full text-start text-sm rounded-lg px-3 py-2 text-[var(--paper)] opacity-70 hover:opacity-100 cursor-pointer"
          >
            Log out
          </button>
        </div>
      </aside>

      {open && (
        <div
          className="fixed inset-0 z-20 bg-black/40 md:hidden"
          onClick={() => setOpen(false)}
          aria-hidden="true"
        />
      )}

      <main className="flex-1 min-w-0 pt-14 md:pt-0">
        <div className="max-w-6xl mx-auto px-5 sm:px-8 py-8">{children}</div>
      </main>
    </div>
  );
}
