import Image from "next/image";

/**
 * The real Ahmed Cherif logo (public/logo.png, transparent background).
 * Rendered as-is on light backgrounds; on dark backgrounds (footer, admin
 * sidebar) it's inverted via CSS filter since the mark itself is navy.
 */
export function Logo({ size = 40, invert = false }: { size?: number; invert?: boolean }) {
  return (
    <Image
      src="/logo.png"
      alt="Ahmed Cherif — الحلاق أحمد الشريف"
      width={size}
      height={size}
      priority
      style={{
        height: size,
        width: "auto",
        filter: invert ? "invert(1) brightness(1.6)" : undefined,
      }}
    />
  );
}
