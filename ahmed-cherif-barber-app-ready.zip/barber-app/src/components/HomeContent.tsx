"use client";

import Link from "next/link";
import { useLang } from "@/components/LanguageProvider";
import { OpenStatusBadge } from "@/components/OpenStatusBadge";
import type { PublicSettings } from "@/lib/settings-client";
import type { Service } from "@/lib/types";

export function HomeContent({
  settings,
  services,
}: {
  settings: PublicSettings;
  services: Service[];
}) {
  const { lang, t } = useLang();
  const name = lang === "ar" ? settings.business_name_ar : settings.business_name_en;
  const tagline = lang === "ar" ? settings.tagline_ar : settings.tagline_en;
  const currency = lang === "ar" ? settings.currency_ar : settings.currency;

  return (
    <>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div
          className="absolute inset-0 -z-10"
          style={{
            background:
              "radial-gradient(120% 100% at 50% 0%, var(--coffee-light) 0%, var(--paper) 55%)",
          }}
        />
        <div className="max-w-6xl mx-auto px-5 sm:px-8 pt-20 pb-24 sm:pt-28 sm:pb-32 text-center">
          <p className="mustache-divider text-xs tracking-[0.3em] uppercase mb-6">
            {lang === "ar" ? "صالون حلاقة فاخر" : "Premium Barber Lounge"}
          </p>
          <h1
            className="font-display text-5xl sm:text-7xl leading-[1.05] mb-6"
            style={{ color: "var(--ink)" }}
          >
            {name}
          </h1>
          <p className="text-lg sm:text-xl italic font-display mb-8" style={{ color: "var(--coffee)" }}>
            {tagline}
          </p>
          <div className="flex items-center justify-center gap-4 flex-wrap">
            <Link
              href="/book"
              className="razor-edge inline-flex items-center rounded-full px-7 py-3.5 text-white font-semibold shadow-lg transition-transform hover:scale-[1.03]"
              style={{ background: "var(--coffee)" }}
            >
              {t("book_cta")}
            </Link>
            <OpenStatusBadge />
          </div>
        </div>
      </section>

      {/* ABOUT */}
      <section className="max-w-4xl mx-auto px-5 sm:px-8 py-16 text-center">
        <h2 className="font-display text-3xl razor-edge mb-8">{t("about_title")}</h2>
        <p className="text-base sm:text-lg leading-relaxed" style={{ color: "var(--ink-soft)" }}>
          {lang === "ar"
            ? "في قلب صفاقس، يقدّم أحمد الشريف تجربة حلاقة تجمع بين الحرفية التقليدية واللمسة العصرية. كل زيارة هي لحظة عناية واهتمام بالتفاصيل."
            : "In the heart of Sfax, Ahmed Cherif offers a barbering experience where traditional craft meets a modern touch. Every visit is a moment of care and attention to detail."}
        </p>
      </section>

      {/* SERVICES */}
      <section id="services" className="max-w-6xl mx-auto px-5 sm:px-8 py-16">
        <h2 className="font-display text-3xl text-center razor-edge mb-14 mx-auto w-fit">
          {t("services_title")}
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((s) => (
            <div
              key={s.id}
              className="rounded-2xl border p-6 flex flex-col gap-3 transition-shadow hover:shadow-lg"
              style={{ borderColor: "var(--coffee-light)", background: "white" }}
            >
              <h3 className="font-display text-xl">{lang === "ar" ? s.name_ar : s.name_en}</h3>
              <div className="flex items-baseline justify-between mt-auto pt-2">
                <span className="text-sm opacity-60">
                  {s.duration_minutes} {t("minutes")}
                </span>
                <span className="font-semibold text-lg" style={{ color: "var(--coffee)" }}>
                  {s.price} {currency}
                </span>
              </div>
            </div>
          ))}
        </div>
        <div className="text-center mt-12">
          <Link
            href="/book"
            className="razor-edge inline-flex items-center rounded-full px-7 py-3.5 text-white font-semibold shadow-lg transition-transform hover:scale-[1.03]"
            style={{ background: "var(--coffee)" }}
          >
            {t("book_cta")}
          </Link>
        </div>
      </section>

      {/* GALLERY */}
      <section className="py-16" style={{ background: "var(--paper-warm)" }}>
        <div className="max-w-6xl mx-auto px-5 sm:px-8">
          <h2 className="font-display text-3xl text-center razor-edge mb-14 mx-auto w-fit">
            {t("gallery_title")}
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((i) => (
              <div
                key={i}
                className="aspect-square rounded-2xl flex items-center justify-center text-sm opacity-40"
                style={{ background: "var(--coffee-light)", color: "var(--coffee-dark)" }}
              >
                {lang === "ar" ? "صورة قادمة" : "Photo coming soon"}
              </div>
            ))}
          </div>
          <p className="text-center text-xs opacity-50 mt-4">
            {lang === "ar"
              ? "سيتم استبدال هذه الصور بصور حقيقية للصالون قريبًا."
              : "These placeholders will be replaced with real shop photos."}
          </p>
        </div>
      </section>

      {/* LOCATION + CONTACT */}
      <section id="contact" className="max-w-6xl mx-auto px-5 sm:px-8 py-16 grid sm:grid-cols-2 gap-10">
        <div>
          <h2 className="font-display text-2xl razor-edge mb-6 w-fit">{t("location_title")}</h2>
          <p className="mb-4" style={{ color: "var(--ink-soft)" }}>
            {lang === "ar" ? settings.address_ar : settings.address_en}
          </p>
          <a
            href={settings.google_maps_url}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 text-sm font-semibold underline underline-offset-4"
            style={{ color: "var(--coffee)" }}
          >
            {t("view_on_maps")} →
          </a>
        </div>
        <div>
          <h2 className="font-display text-2xl razor-edge mb-6 w-fit">{t("contact_title")}</h2>
          <p dir="ltr" className="text-lg font-medium" style={{ color: "var(--ink-soft)" }}>
            {settings.phone}
          </p>
        </div>
      </section>
    </>
  );
}
