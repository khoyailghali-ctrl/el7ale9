"use client";

import { useState } from "react";
import { useLang } from "@/components/LanguageProvider";
import { useToast } from "@/components/Toast";
import type { Appointment } from "@/lib/types";

export function MyAppointmentsFlow() {
  const { lang, t } = useLang();
  const { push } = useToast();
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [appointments, setAppointments] = useState<Appointment[] | null>(null);
  const [cancellingId, setCancellingId] = useState<number | null>(null);

  const search = async () => {
    if (phone.trim().length < 6) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/appointments/lookup?phone=${encodeURIComponent(phone)}`);
      const data = await res.json();
      setAppointments(data.appointments || []);
    } catch {
      push(lang === "ar" ? "حدث خطأ ما." : "Something went wrong.", "error");
    } finally {
      setLoading(false);
    }
  };

  const cancel = async (id: number) => {
    setCancellingId(id);
    try {
      const res = await fetch(`/api/appointments/${id}/cancel`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (data.error === "past_cancellation_window") {
          push(t("cannot_cancel"), "error");
        } else {
          push(lang === "ar" ? "تعذر الإلغاء." : "Could not cancel.", "error");
        }
        return;
      }
      push(lang === "ar" ? "تم إلغاء الموعد." : "Appointment cancelled.", "success");
      setAppointments((prev) =>
        prev ? prev.map((a) => (a.id === id ? { ...a, status: "CANCELLED" } : a)) : prev
      );
    } finally {
      setCancellingId(null);
    }
  };

  return (
    <div className="max-w-xl mx-auto px-5 sm:px-8 py-14">
      <h1 className="font-display text-3xl mb-2">{t("my_appointments_title")}</h1>
      <p className="opacity-60 mb-6 text-sm">{t("lookup_phone_prompt")}</p>

      <div className="flex gap-2 mb-10">
        <input
          dir="ltr"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && search()}
          placeholder="22 123 456"
          className="flex-1 rounded-lg border px-4 py-3 focus:outline-none"
          style={{ borderColor: "var(--coffee-light)" }}
        />
        <button
          onClick={search}
          disabled={loading}
          className="rounded-lg px-5 py-3 text-white font-semibold cursor-pointer disabled:opacity-50"
          style={{ background: "var(--coffee)" }}
        >
          {t("lookup")}
        </button>
      </div>

      {appointments !== null && (
        <div className="space-y-3">
          {appointments.length === 0 && <p className="opacity-60 text-sm">{t("no_appointments")}</p>}
          {appointments.map((a) => (
            <div
              key={a.id}
              className="rounded-xl border p-4 flex items-center justify-between gap-4"
              style={{ borderColor: "var(--coffee-light)" }}
            >
              <div>
                <p className="font-medium">{lang === "ar" ? a.service_name_ar : a.service_name_en}</p>
                <p className="text-sm opacity-60">
                  {a.date} — {a.start_time}
                </p>
                <StatusPill status={a.status} label={t(`status_${a.status}` as never)} />
              </div>
              {a.status === "CONFIRMED" && (
                <button
                  onClick={() => cancel(a.id)}
                  disabled={cancellingId === a.id}
                  className="text-sm font-medium px-3 py-1.5 rounded-full border cursor-pointer disabled:opacity-50"
                  style={{ borderColor: "var(--red)", color: "var(--red)" }}
                >
                  {t("cancel")}
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StatusPill({ status, label }: { status: string; label: string }) {
  const colors: Record<string, string> = {
    CONFIRMED: "var(--green)",
    COMPLETED: "var(--coffee)",
    CANCELLED: "#948a76",
    NO_SHOW: "var(--red)",
  };
  return (
    <span
      className="inline-block mt-1.5 text-xs font-semibold px-2 py-0.5 rounded-full"
      style={{ color: colors[status], background: `${colors[status]}1a` }}
    >
      {label}
    </span>
  );
}
