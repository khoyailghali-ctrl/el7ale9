"use client";

import Link from "next/link";
import { useLang } from "./LanguageProvider";
import { Logo } from "./Logo";
import type { PublicSettings } from "@/lib/settings-client";

export function Footer({ settings }: { settings: PublicSettings }) {
  const { lang, t } = useLang();
  const name = lang === "ar" ? settings.business_name_ar : settings.business_name_en;
  const address = lang === "ar" ? settings.address_ar : settings.address_en;

  return (
    <footer className="mt-24 border-t" style={{ borderColor: "var(--coffee-light)", background: "var(--ink)" }}>
      <div className="max-w-6xl mx-auto px-5 sm:px-8 py-14 grid gap-10 sm:grid-cols-3 text-[var(--paper)]">
        <div>
          <div className="mb-3">
            <Logo size={44} invert />
          </div>
          <p className="text-sm opacity-70 max-w-xs">
            {lang === "ar" ? settings.tagline_ar : settings.tagline_en}
          </p>
        </div>
        <div className="text-sm opacity-80 space-y-2">
          <p>{address}</p>
          <p dir="ltr" className="opacity-80">
            {settings.phone}
          </p>
        </div>
        <div className="text-sm opacity-80 space-y-2">
          <Link href="/book" className="block hover:opacity-100 opacity-90">
            {t("nav_book")}
          </Link>
          <Link href="/my-appointments" className="block hover:opacity-100 opacity-90">
            {t("nav_my_appointments")}
          </Link>
          <Link href="/admin/login" className="block hover:opacity-100 opacity-60 text-xs mt-4">
            Admin
          </Link>
        </div>
      </div>
      <div className="text-center text-xs py-5 opacity-50 text-[var(--paper)]">
        © {new Date().getFullYear()} {name} — {t("footer_rights")}
      </div>
    </footer>
  );
}
