"use client";

import { useEffect, useState } from "react";
import { useLang } from "./LanguageProvider";

export function OpenStatusBadge() {
  const { t } = useLang();
  const [open, setOpen] = useState<boolean | null>(null);

  useEffect(() => {
    let cancelled = false;
    const load = () => {
      fetch("/api/shop-status")
        .then((r) => r.json())
        .then((d) => {
          if (!cancelled) setOpen(Boolean(d.open));
        })
        .catch(() => {});
    };
    load();
    const interval = setInterval(load, 60_000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, []);

  if (open === null) return null;

  return (
    <span
      className="inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold tracking-wide"
      style={{
        background: open ? "rgba(63,107,74,0.12)" : "rgba(165,67,58,0.12)",
        color: open ? "var(--green)" : "var(--red)",
      }}
    >
      <span
        className="h-2 w-2 rounded-full"
        style={{ background: open ? "var(--green)" : "var(--red)" }}
      />
      {open ? t("open_now") : t("closed_now")}
    </span>
  );
}
