"use client";

import { useEffect, useState } from "react";
import { useLang } from "./LanguageProvider";

interface Announcement {
  id: number;
  title_en: string;
  title_ar: string;
  message_en: string;
  message_ar: string;
}

export function AnnouncementBanner() {
  const { lang, t } = useLang();
  const [items, setItems] = useState<Announcement[]>([]);
  const [dismissed, setDismissed] = useState<number[]>([]);

  useEffect(() => {
    fetch("/api/announcements")
      .then((r) => r.json())
      .then((d) => setItems(Array.isArray(d) ? d : []))
      .catch(() => {});
    try {
      const stored = JSON.parse(localStorage.getItem("dismissed_announcements") || "[]");
      setDismissed(stored);
    } catch {
      // ignore
    }
  }, []);

  const visible = items.filter((a) => !dismissed.includes(a.id));
  if (visible.length === 0) return null;

  const dismiss = (id: number) => {
    const next = [...dismissed, id];
    setDismissed(next);
    localStorage.setItem("dismissed_announcements", JSON.stringify(next));
  };

  return (
    <div className="max-w-6xl mx-auto px-5 sm:px-8 pt-6 space-y-3">
      {visible.map((a) => (
        <div
          key={a.id}
          className="flex items-start gap-3 rounded-xl border px-4 py-3 text-sm"
          style={{ borderColor: "var(--brass)", background: "rgba(180,138,82,0.08)" }}
        >
          <span aria-hidden="true">📢</span>
          <div className="flex-1">
            <p className="font-semibold" style={{ color: "var(--coffee-dark)" }}>
              {lang === "ar" ? a.title_ar : a.title_en}
            </p>
            <p style={{ color: "var(--ink-soft)" }}>{lang === "ar" ? a.message_ar : a.message_en}</p>
          </div>
          <button
            onClick={() => dismiss(a.id)}
            aria-label="Dismiss"
            className="opacity-50 hover:opacity-100 cursor-pointer px-1"
          >
            ✕
          </button>
        </div>
      ))}
    </div>
  );
}
