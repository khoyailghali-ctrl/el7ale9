"use client";

import { useEffect, useMemo, useState } from "react";
import { useLang } from "@/components/LanguageProvider";
import { useToast } from "@/components/Toast";
import type { Service, SlotInfo } from "@/lib/types";

type Step = "service" | "date" | "time" | "info" | "confirm";
const STEPS: Step[] = ["service", "date", "time", "info", "confirm"];

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function nextNDays(n: number) {
  const out: string[] = [];
  const base = new Date();
  for (let i = 0; i < n; i++) {
    const d = new Date(base.getTime() + i * 86400000);
    out.push(d.toISOString().slice(0, 10));
  }
  return out;
}

export function BookingFlow() {
  const { lang, t } = useLang();
  const { push } = useToast();

  const [step, setStep] = useState<Step>("service");
  const [services, setServices] = useState<Service[]>([]);
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [date, setDate] = useState<string>(todayStr());
  const [slots, setSlots] = useState<SlotInfo[]>([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [confirmedId, setConfirmedId] = useState<number | null>(null);

  useEffect(() => {
    fetch("/api/services")
      .then((r) => r.json())
      .then((d) => setServices(Array.isArray(d) ? d : []))
      .catch(() => push(lang === "ar" ? "تعذر تحميل الخدمات" : "Failed to load services", "error"));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!selectedService || step !== "time") return;
    setSlotsLoading(true);
    setSelectedTime(null);
    fetch(`/api/availability?serviceId=${selectedService.id}&date=${date}`)
      .then((r) => r.json())
      .then((d) => setSlots(d.slots || []))
      .catch(() => push(lang === "ar" ? "تعذر تحميل الأوقات" : "Failed to load times", "error"))
      .finally(() => setSlotsLoading(false));
  }, [selectedService, date, step, lang, push]);

  const days = useMemo(() => nextNDays(21), []);

  const goTo = (s: Step) => setStep(s);

  const submitBooking = async () => {
    if (!selectedService || !selectedTime) return;
    setSubmitting(true);
    try {
      const res = await fetch("/api/appointments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          serviceId: selectedService.id,
          date,
          startTime: selectedTime,
          name,
          phone,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (data.error === "slot_taken") {
          push(t("slot_taken"), "error");
          setStep("time");
          // refresh slots to reflect reality
          setSelectedTime(null);
          const r = await fetch(`/api/availability?serviceId=${selectedService.id}&date=${date}`);
          const d = await r.json();
          setSlots(d.slots || []);
        } else if (data.error === "shop_closed") {
          push(t("shop_closed_msg"), "error");
        } else {
          push(lang === "ar" ? "حدث خطأ ما، حاول مرة أخرى." : "Something went wrong. Please try again.", "error");
        }
        return;
      }
      setConfirmedId(data.appointmentId);
      push(t("booking_confirmed"), "success");
    } catch {
      push(lang === "ar" ? "حدث خطأ ما، حاول مرة أخرى." : "Something went wrong. Please try again.", "error");
    } finally {
      setSubmitting(false);
    }
  };

  if (confirmedId) {
    return (
      <div className="max-w-xl mx-auto text-center py-16 px-5">
        <div
          className="mx-auto mb-6 h-16 w-16 rounded-full flex items-center justify-center text-2xl"
          style={{ background: "rgba(63,107,74,0.15)", color: "var(--green)" }}
        >
          ✓
        </div>
        <h1 className="font-display text-3xl mb-3">{t("booking_confirmed")}</h1>
        <p className="opacity-70 mb-8">
          {selectedService && (lang === "ar" ? selectedService.name_ar : selectedService.name_en)} — {date} — {selectedTime}
        </p>
        <a
          href="/my-appointments"
          className="inline-flex items-center rounded-full px-6 py-3 text-white font-semibold"
          style={{ background: "var(--coffee)" }}
        >
          {t("nav_my_appointments")}
        </a>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto px-5 sm:px-8 py-12">
      {/* stepper */}
      <ol className="flex items-center justify-between mb-12 text-xs sm:text-sm">
        {STEPS.map((s, i) => {
          const idx = STEPS.indexOf(step);
          const active = i <= idx;
          return (
            <li key={s} className="flex-1 flex items-center">
              <div className="flex flex-col items-center flex-1">
                <div
                  className="h-7 w-7 rounded-full flex items-center justify-center text-xs font-semibold mb-1.5"
                  style={{
                    background: active ? "var(--coffee)" : "var(--coffee-light)",
                    color: active ? "white" : "var(--coffee-dark)",
                  }}
                >
                  {i + 1}
                </div>
                <span className="opacity-70 text-center hidden sm:block">
                  {t(`step_${s}` as never)}
                </span>
              </div>
              {i < STEPS.length - 1 && (
                <div className="h-px flex-1 -mt-5" style={{ background: "var(--coffee-light)" }} />
              )}
            </li>
          );
        })}
      </ol>

      {step === "service" && (
        <div>
          <h1 className="font-display text-2xl mb-6">{t("select_service")}</h1>
          <div className="grid gap-3">
            {services.map((s) => (
              <button
                key={s.id}
                onClick={() => {
                  setSelectedService(s);
                  goTo("date");
                }}
                className="flex items-center justify-between rounded-xl border px-5 py-4 text-start transition-colors hover:bg-[var(--paper-warm)] cursor-pointer"
                style={{ borderColor: "var(--coffee-light)" }}
              >
                <span>
                  <span className="block font-medium">{lang === "ar" ? s.name_ar : s.name_en}</span>
                  <span className="block text-xs opacity-60 mt-0.5">
                    {s.duration_minutes} {t("minutes")}
                  </span>
                </span>
                <span className="font-semibold" style={{ color: "var(--coffee)" }}>
                  {s.price} {lang === "ar" ? "د.ت" : "TND"}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {step === "date" && selectedService && (
        <div>
          <h1 className="font-display text-2xl mb-6">{t("select_date")}</h1>
          <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5 mb-8 max-h-80 overflow-y-auto scrollbar-thin">
            {days.map((d) => {
              const dObj = new Date(d + "T00:00:00");
              const isSelected = d === date;
              return (
                <button
                  key={d}
                  onClick={() => setDate(d)}
                  className="rounded-xl border px-3 py-3 text-sm transition-colors cursor-pointer"
                  style={{
                    borderColor: isSelected ? "var(--coffee)" : "var(--coffee-light)",
                    background: isSelected ? "var(--coffee)" : "white",
                    color: isSelected ? "white" : "var(--ink)",
                  }}
                >
                  <span className="block font-semibold">{dObj.getDate()}</span>
                  <span className="block text-xs opacity-80">
                    {dObj.toLocaleDateString(lang === "ar" ? "ar-TN" : "en-US", { month: "short" })}
                  </span>
                </button>
              );
            })}
          </div>
          <StepNav onBack={() => goTo("service")} onNext={() => goTo("time")} t={t} />
        </div>
      )}

      {step === "time" && selectedService && (
        <div>
          <h1 className="font-display text-2xl mb-2">{t("select_time")}</h1>
          <p className="text-sm opacity-60 mb-6">{date}</p>
          <div className="flex items-center gap-4 text-xs mb-4">
            <Legend color="var(--green)" label={t("available")} />
            <Legend color="var(--red)" label={t("booked")} />
            <Legend color="#c9bfa8" label={t("closed")} />
          </div>
          {slotsLoading ? (
            <p className="opacity-60 text-sm py-8 text-center">…</p>
          ) : slots.filter((s) => s.status !== "closed").length === 0 ? (
            <p className="opacity-60 text-sm py-8 text-center">
              {lang === "ar" ? "لا توجد أوقات متاحة لهذا اليوم." : "No available times for this date."}
            </p>
          ) : (
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5 mb-8 max-h-96 overflow-y-auto scrollbar-thin">
              {slots.map((s) => {
                const disabled = s.status !== "available";
                const isSelected = selectedTime === s.time;
                return (
                  <button
                    key={s.time}
                    disabled={disabled}
                    onClick={() => setSelectedTime(s.time)}
                    className="rounded-lg border px-2 py-2.5 text-sm font-medium transition-colors relative"
                    style={{
                      cursor: disabled ? "not-allowed" : "pointer",
                      borderColor: isSelected ? "var(--brass)" : "var(--coffee-light)",
                      background: isSelected
                        ? "var(--brass-soft)"
                        : s.status === "booked"
                        ? "rgba(165,67,58,0.06)"
                        : s.status === "closed"
                        ? "#f1ede3"
                        : "white",
                      color: disabled ? "#a89c85" : "var(--ink)",
                      opacity: disabled ? 0.6 : 1,
                    }}
                    aria-label={`${s.time} — ${t(s.status as never)}`}
                  >
                    {s.time}
                  </button>
                );
              })}
            </div>
          )}
          <StepNav onBack={() => goTo("date")} onNext={() => goTo("info")} nextDisabled={!selectedTime} t={t} />
        </div>
      )}

      {step === "info" && (
        <div>
          <h1 className="font-display text-2xl mb-6">{t("step_info")}</h1>
          <div className="space-y-4 mb-8">
            <div>
              <label className="block text-sm font-medium mb-1.5">{t("your_name")}</label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full rounded-lg border px-4 py-3 focus:outline-none"
                style={{ borderColor: "var(--coffee-light)" }}
                placeholder={lang === "ar" ? "محمد بن علي" : "Mohamed Ben Ali"}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1.5">{t("your_phone")}</label>
              <input
                dir="ltr"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full rounded-lg border px-4 py-3 focus:outline-none"
                style={{ borderColor: "var(--coffee-light)" }}
                placeholder="22 123 456"
              />
            </div>
          </div>
          <StepNav
            onBack={() => goTo("time")}
            onNext={() => goTo("confirm")}
            nextDisabled={name.trim().length < 2 || phone.trim().length < 6}
            t={t}
          />
        </div>
      )}

      {step === "confirm" && selectedService && (
        <div>
          <h1 className="font-display text-2xl mb-6">{t("step_confirm")}</h1>
          <div className="rounded-xl border p-6 mb-8 space-y-3" style={{ borderColor: "var(--coffee-light)" }}>
            <SummaryRow label={t("select_service")} value={lang === "ar" ? selectedService.name_ar : selectedService.name_en} />
            <SummaryRow label={t("select_date")} value={date} />
            <SummaryRow label={t("select_time")} value={selectedTime || ""} />
            <SummaryRow label={t("your_name")} value={name} />
            <SummaryRow label={t("your_phone")} value={phone} />
            <SummaryRow
              label={lang === "ar" ? "السعر" : "Price"}
              value={`${selectedService.price} ${lang === "ar" ? "د.ت" : "TND"}`}
            />
          </div>
          <StepNav
            onBack={() => goTo("info")}
            onNext={submitBooking}
            nextLabel={t("confirm_booking")}
            nextDisabled={submitting}
            t={t}
          />
        </div>
      )}
    </div>
  );
}

function Legend({ color, label }: { color: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className="h-2.5 w-2.5 rounded-full" style={{ background: color }} />
      {label}
    </span>
  );
}

function SummaryRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between text-sm">
      <span className="opacity-60">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}

function StepNav({
  onBack,
  onNext,
  nextDisabled,
  nextLabel,
  t,
}: {
  onBack: () => void;
  onNext: () => void;
  nextDisabled?: boolean;
  nextLabel?: string;
  t: (k: never) => string;
}) {
  return (
    <div className="flex items-center justify-between">
      <button onClick={onBack} className="text-sm font-medium opacity-70 hover:opacity-100 cursor-pointer">
        ← {t("back" as never)}
      </button>
      <button
        onClick={onNext}
        disabled={nextDisabled}
        className="rounded-full px-6 py-3 text-white font-semibold disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer transition-transform enabled:hover:scale-[1.02]"
        style={{ background: "var(--coffee)" }}
      >
        {nextLabel || t("next" as never)}
      </button>
    </div>
  );
}
