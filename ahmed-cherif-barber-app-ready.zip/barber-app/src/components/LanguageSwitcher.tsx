"use client";

import { useLang } from "./LanguageProvider";

export function LanguageSwitcher() {
  const { lang, setLang } = useLang();
  return (
    <button
      onClick={() => setLang(lang === "ar" ? "en" : "ar")}
      className="text-sm font-medium px-3 py-1.5 rounded-full border transition-colors cursor-pointer"
      style={{ borderColor: "var(--coffee-light)", color: "var(--coffee-dark)" }}
      aria-label="Switch language"
    >
      {lang === "ar" ? "English" : "العربية"}
    </button>
  );
}
