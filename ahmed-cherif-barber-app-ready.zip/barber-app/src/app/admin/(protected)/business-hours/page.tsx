"use client";

import { useEffect, useState } from "react";
import type { BusinessHoursDay, Period } from "@/lib/types";

const DAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export default function BusinessHoursPage() {
  const [days, setDays] = useState<BusinessHoursDay[]>([]);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch("/api/business-hours")
      .then((r) => r.json())
      .then((d) => {
        const full: BusinessHoursDay[] = [0, 1, 2, 3, 4, 5, 6].map(
          (dow) => d.find((x: BusinessHoursDay) => x.day_of_week === dow) || { day_of_week: dow, is_open: 0, periods: [] }
        );
        setDays(full);
      });
  }, []);

  const updateDay = (dow: number, patch: Partial<BusinessHoursDay>) => {
    setDays((prev) => prev.map((d) => (d.day_of_week === dow ? { ...d, ...patch } : d)));
  };

  const updatePeriod = (dow: number, idx: number, patch: Partial<Period>) => {
    setDays((prev) =>
      prev.map((d) =>
        d.day_of_week === dow
          ? { ...d, periods: d.periods.map((p, i) => (i === idx ? { ...p, ...patch } : p)) }
          : d
      )
    );
  };

  const addPeriod = (dow: number) => {
    setDays((prev) =>
      prev.map((d) =>
        d.day_of_week === dow ? { ...d, periods: [...d.periods, { start: "10:00", end: "18:00" }] } : d
      )
    );
  };

  const removePeriod = (dow: number, idx: number) => {
    setDays((prev) =>
      prev.map((d) => (d.day_of_week === dow ? { ...d, periods: d.periods.filter((_, i) => i !== idx) } : d))
    );
  };

  const save = async () => {
    setSaving(true);
    setSaved(false);
    await fetch("/api/business-hours", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ days: days.map((d) => ({ ...d, is_open: Boolean(d.is_open) })) }),
    });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div>
      <h1 className="font-display text-3xl mb-2">Business Hours</h1>
      <p className="text-sm opacity-60 mb-8">
        Add multiple periods per day for split shifts (e.g. a midday break).
      </p>

      <div className="space-y-3 max-w-2xl">
        {days.map((d) => (
          <div key={d.day_of_week} className="rounded-2xl border p-4" style={{ borderColor: "var(--coffee-light)", background: "white" }}>
            <div className="flex items-center justify-between mb-3">
              <label className="flex items-center gap-2 font-medium">
                <input
                  type="checkbox"
                  checked={Boolean(d.is_open)}
                  onChange={(e) => updateDay(d.day_of_week, { is_open: e.target.checked ? 1 : 0 })}
                />
                {DAY_NAMES[d.day_of_week]}
              </label>
              {d.is_open ? (
                <button onClick={() => addPeriod(d.day_of_week)} className="text-xs underline cursor-pointer">
                  + add period
                </button>
              ) : (
                <span className="text-xs opacity-50">Closed</span>
              )}
            </div>
            {d.is_open ? (
              <div className="space-y-2">
                {d.periods.map((p, idx) => (
                  <div key={idx} className="flex items-center gap-2">
                    <input
                      type="time"
                      value={p.start}
                      onChange={(e) => updatePeriod(d.day_of_week, idx, { start: e.target.value })}
                      className="rounded-lg border px-2 py-1.5 text-sm"
                      style={{ borderColor: "var(--coffee-light)" }}
                    />
                    <span className="opacity-50 text-sm">to</span>
                    <input
                      type="time"
                      value={p.end}
                      onChange={(e) => updatePeriod(d.day_of_week, idx, { end: e.target.value })}
                      className="rounded-lg border px-2 py-1.5 text-sm"
                      style={{ borderColor: "var(--coffee-light)" }}
                    />
                    <button
                      onClick={() => removePeriod(d.day_of_week, idx)}
                      className="text-xs opacity-50 hover:opacity-100 cursor-pointer ms-2"
                    >
                      remove
                    </button>
                  </div>
                ))}
                {d.periods.length === 0 && (
                  <p className="text-xs opacity-40">No periods — add one, or this day has no availability.</p>
                )}
              </div>
            ) : null}
          </div>
        ))}
      </div>

      <button
        onClick={save}
        disabled={saving}
        className="mt-6 rounded-full px-6 py-3 text-white font-semibold cursor-pointer disabled:opacity-50"
        style={{ background: "var(--coffee)" }}
      >
        {saving ? "Saving…" : "Save business hours"}
      </button>
      {saved && <span className="ms-3 text-sm" style={{ color: "var(--green)" }}>Saved ✓</span>}
    </div>
  );
}
