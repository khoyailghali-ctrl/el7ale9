"use client";

import { useEffect, useState, useCallback } from "react";
import type { Announcement } from "@/lib/types";

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

export default function AnnouncementsPage() {
  const [items, setItems] = useState<Announcement[]>([]);
  const [titleEn, setTitleEn] = useState("");
  const [titleAr, setTitleAr] = useState("");
  const [messageEn, setMessageEn] = useState("");
  const [messageAr, setMessageAr] = useState("");
  const [startDate, setStartDate] = useState(todayStr());
  const [endDate, setEndDate] = useState(todayStr());
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => {
    fetch("/api/announcements?all=1")
      .then((r) => r.json())
      .then((d) => setItems(Array.isArray(d) ? d : []));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const create = async () => {
    setSaving(true);
    await fetch("/api/announcements", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title_en: titleEn,
        title_ar: titleAr,
        message_en: messageEn,
        message_ar: messageAr,
        start_date: startDate,
        end_date: endDate,
        active: true,
      }),
    });
    setSaving(false);
    setTitleEn("");
    setTitleAr("");
    setMessageEn("");
    setMessageAr("");
    load();
  };

  const toggleActive = async (a: Announcement) => {
    await fetch(`/api/announcements/${a.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active: !a.active }),
    });
    load();
  };

  const remove = async (id: number) => {
    await fetch(`/api/announcements/${id}`, { method: "DELETE" });
    load();
  };

  return (
    <div>
      <h1 className="font-display text-3xl mb-8">Announcements</h1>

      <div className="rounded-2xl border p-5 mb-8 max-w-lg" style={{ borderColor: "var(--coffee-light)", background: "white" }}>
        <h2 className="font-medium mb-4">New announcement</h2>
        <div className="space-y-3">
          <Field label="Title (English)">
            <input value={titleEn} onChange={(e) => setTitleEn(e.target.value)} className="input" />
          </Field>
          <Field label="Title (Arabic)">
            <input dir="rtl" value={titleAr} onChange={(e) => setTitleAr(e.target.value)} className="input" />
          </Field>
          <Field label="Message (English)">
            <textarea value={messageEn} onChange={(e) => setMessageEn(e.target.value)} className="input" rows={2} />
          </Field>
          <Field label="Message (Arabic)">
            <textarea dir="rtl" value={messageAr} onChange={(e) => setMessageAr(e.target.value)} className="input" rows={2} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Start date">
              <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="input" />
            </Field>
            <Field label="End date">
              <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="input" />
            </Field>
          </div>
        </div>
        <button
          onClick={create}
          disabled={saving || !titleEn || !titleAr || !messageEn || !messageAr}
          className="mt-4 rounded-full px-5 py-2.5 text-white text-sm font-semibold cursor-pointer disabled:opacity-50"
          style={{ background: "var(--coffee)" }}
        >
          Publish
        </button>
        <style jsx>{`
          .input {
            width: 100%;
            border: 1px solid var(--coffee-light);
            border-radius: 8px;
            padding: 8px 12px;
            font-size: 14px;
          }
        `}</style>
      </div>

      <div className="space-y-2 max-w-lg">
        {items.map((a) => (
          <div
            key={a.id}
            className="rounded-xl border px-4 py-3"
            style={{ borderColor: "var(--coffee-light)", background: "white", opacity: a.active ? 1 : 0.5 }}
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="font-medium">{a.title_en}</p>
                <p className="text-xs opacity-60">
                  {a.start_date} → {a.end_date}
                </p>
              </div>
              <div className="flex gap-3 text-xs shrink-0">
                <button onClick={() => toggleActive(a)} className="underline cursor-pointer">
                  {a.active ? "Deactivate" : "Activate"}
                </button>
                <button onClick={() => remove(a.id)} className="opacity-60 hover:opacity-100 cursor-pointer">
                  Delete
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-xs font-medium mb-1 opacity-70">{label}</span>
      {children}
    </label>
  );
}
