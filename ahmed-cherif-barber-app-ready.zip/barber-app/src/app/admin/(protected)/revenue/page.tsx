"use client";

import { useEffect, useState } from "react";

interface RevenuePeriod {
  revenue: number;
  count: number;
}
interface RevenueData {
  today: RevenuePeriod;
  week: RevenuePeriod;
  month: RevenuePeriod;
  series: Array<{ date: string; revenue: number }>;
}

export default function RevenuePage() {
  const [data, setData] = useState<RevenueData | null>(null);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [custom, setCustom] = useState<RevenuePeriod | null>(null);

  useEffect(() => {
    fetch("/api/dashboard/revenue")
      .then((r) => r.json())
      .then(setData);
  }, []);

  const runCustom = async () => {
    if (!from || !to) return;
    const res = await fetch(`/api/dashboard/revenue?from=${from}&to=${to}`);
    const d = await res.json();
    setCustom(d.custom);
  };

  const maxRevenue = data ? Math.max(...data.series.map((s) => s.revenue), 1) : 1;

  return (
    <div>
      <h1 className="font-display text-3xl mb-8">Revenue</h1>

      <div className="grid grid-cols-3 gap-4 mb-10 max-w-xl">
        <RevCard label="Today" period={data?.today} />
        <RevCard label="This week" period={data?.week} />
        <RevCard label="This month" period={data?.month} />
      </div>

      <h2 className="font-display text-xl mb-4">Last 14 days</h2>
      <div className="rounded-2xl border p-6 mb-10 max-w-2xl" style={{ borderColor: "var(--coffee-light)", background: "white" }}>
        {data && data.series.length > 0 ? (
          <div className="flex items-end gap-1.5 h-40">
            {data.series.map((s) => (
              <div key={s.date} className="flex-1 flex flex-col items-center justify-end gap-1" title={`${s.date}: ${s.revenue} TND`}>
                <div
                  className="w-full rounded-t"
                  style={{
                    height: `${Math.max((s.revenue / maxRevenue) * 100, 3)}%`,
                    background: "var(--coffee)",
                  }}
                />
                <span className="text-[10px] opacity-40">{s.date.slice(8)}</span>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm opacity-50 text-center py-8">No completed appointments yet.</p>
        )}
      </div>

      <h2 className="font-display text-xl mb-4">Custom range</h2>
      <div className="flex items-center gap-3 mb-4 flex-wrap">
        <input
          type="date"
          value={from}
          onChange={(e) => setFrom(e.target.value)}
          className="rounded-lg border px-3 py-2 text-sm"
          style={{ borderColor: "var(--coffee-light)" }}
        />
        <span className="opacity-50 text-sm">to</span>
        <input
          type="date"
          value={to}
          onChange={(e) => setTo(e.target.value)}
          className="rounded-lg border px-3 py-2 text-sm"
          style={{ borderColor: "var(--coffee-light)" }}
        />
        <button
          onClick={runCustom}
          className="rounded-full px-5 py-2 text-white text-sm font-semibold cursor-pointer"
          style={{ background: "var(--coffee)" }}
        >
          Calculate
        </button>
      </div>
      {custom && (
        <p className="text-lg">
          <strong>{custom.revenue} TND</strong>{" "}
          <span className="opacity-60 text-sm">from {custom.count} completed appointments</span>
        </p>
      )}
    </div>
  );
}

function RevCard({ label, period }: { label: string; period?: RevenuePeriod }) {
  return (
    <div className="rounded-2xl border p-4" style={{ borderColor: "var(--coffee-light)", background: "white" }}>
      <p className="text-xs opacity-60 mb-1">{label}</p>
      <p className="text-2xl font-semibold" style={{ color: "var(--coffee)" }}>
        {period ? `${period.revenue} TND` : "—"}
      </p>
      {period && <p className="text-xs opacity-40 mt-0.5">{period.count} appointments</p>}
    </div>
  );
}
