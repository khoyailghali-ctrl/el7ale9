"use client";

import { useEffect, useState, useCallback } from "react";
import type { Service } from "@/lib/types";

export default function AdminServicesPage() {
  const [services, setServices] = useState<Service[]>([]);
  const [editing, setEditing] = useState<Service | "new" | null>(null);

  const load = useCallback(() => {
    fetch("/api/services?all=1")
      .then((r) => r.json())
      .then((d) => setServices(Array.isArray(d) ? d : []));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const toggleActive = async (s: Service) => {
    await fetch(`/api/services/${s.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active: !s.active }),
    });
    load();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-display text-3xl">Services</h1>
        <button
          onClick={() => setEditing("new")}
          className="rounded-full px-5 py-2.5 text-white text-sm font-semibold cursor-pointer"
          style={{ background: "var(--coffee)" }}
        >
          + New service
        </button>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {services.map((s) => (
          <div
            key={s.id}
            className="rounded-2xl border p-5"
            style={{ borderColor: "var(--coffee-light)", background: "white", opacity: s.active ? 1 : 0.5 }}
          >
            <div className="flex items-start justify-between mb-2">
              <h3 className="font-display text-lg">{s.name_en}</h3>
              <span className="text-xs opacity-50">{s.active ? "Active" : "Inactive"}</span>
            </div>
            <p className="text-sm opacity-60 mb-1">{s.name_ar}</p>
            <p className="text-sm mb-4">
              {s.duration_minutes} min · <strong>{s.price} TND</strong>
            </p>
            <div className="flex gap-3 text-sm">
              <button onClick={() => setEditing(s)} className="underline cursor-pointer">
                Edit
              </button>
              <button onClick={() => toggleActive(s)} className="underline cursor-pointer opacity-70">
                {s.active ? "Deactivate" : "Activate"}
              </button>
            </div>
          </div>
        ))}
      </div>

      {editing && (
        <ServiceModal
          service={editing === "new" ? null : editing}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            load();
          }}
        />
      )}
    </div>
  );
}

function ServiceModal({
  service,
  onClose,
  onSaved,
}: {
  service: Service | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [nameEn, setNameEn] = useState(service?.name_en || "");
  const [nameAr, setNameAr] = useState(service?.name_ar || "");
  const [price, setPrice] = useState(service?.price ?? 15);
  const [duration, setDuration] = useState(service?.duration_minutes ?? 30);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const save = async () => {
    setSaving(true);
    setError(null);
    const body = {
      name_en: nameEn,
      name_ar: nameAr,
      price: Number(price),
      duration_minutes: Number(duration),
    };
    const res = service
      ? await fetch(`/api/services/${service.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        })
      : await fetch("/api/services", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ ...body, active: true, sort_order: 99 }),
        });
    setSaving(false);
    if (!res.ok) {
      setError("Could not save. Check the fields.");
      return;
    }
    onSaved();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-2xl p-6"
        style={{ background: "white" }}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-xl">{service ? "Edit service" : "New service"}</h2>
          <button onClick={onClose} className="opacity-50 hover:opacity-100 cursor-pointer">
            ✕
          </button>
        </div>
        {error && (
          <p className="text-sm rounded-lg px-3 py-2 mb-3" style={{ background: "rgba(165,67,58,0.1)", color: "var(--red)" }}>
            {error}
          </p>
        )}
        <div className="space-y-3">
          <div>
            <label className="block text-xs font-medium mb-1 opacity-70">Name (English)</label>
            <input value={nameEn} onChange={(e) => setNameEn(e.target.value)} className="input" />
          </div>
          <div>
            <label className="block text-xs font-medium mb-1 opacity-70">Name (Arabic)</label>
            <input dir="rtl" value={nameAr} onChange={(e) => setNameAr(e.target.value)} className="input" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium mb-1 opacity-70">Price (TND)</label>
              <input type="number" value={price} onChange={(e) => setPrice(Number(e.target.value))} className="input" />
            </div>
            <div>
              <label className="block text-xs font-medium mb-1 opacity-70">Duration (min)</label>
              <input
                type="number"
                value={duration}
                onChange={(e) => setDuration(Number(e.target.value))}
                className="input"
              />
            </div>
          </div>
        </div>
        <button
          onClick={save}
          disabled={saving || !nameEn || !nameAr}
          className="w-full mt-5 rounded-lg py-2.5 text-white font-semibold cursor-pointer disabled:opacity-50"
          style={{ background: "var(--coffee)" }}
        >
          {saving ? "Saving…" : "Save"}
        </button>
        <style jsx>{`
          .input {
            width: 100%;
            border: 1px solid var(--coffee-light);
            border-radius: 8px;
            padding: 8px 12px;
            font-size: 14px;
          }
        `}</style>
      </div>
    </div>
  );
}
