"use client";

import { useEffect, useState, useCallback } from "react";
import type { Closure } from "@/lib/types";

export default function ClosuresPage() {
  const [closures, setClosures] = useState<Closure[]>([]);
  const [date, setDate] = useState("");
  const [fullDay, setFullDay] = useState(true);
  const [startTime, setStartTime] = useState("16:00");
  const [endTime, setEndTime] = useState("18:00");
  const [reason, setReason] = useState("");
  const [saving, setSaving] = useState(false);

  const load = useCallback(() => {
    fetch("/api/closures")
      .then((r) => r.json())
      .then((d) => setClosures(Array.isArray(d) ? d : []));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const create = async () => {
    if (!date) return;
    setSaving(true);
    await fetch("/api/closures", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        date,
        full_day: fullDay,
        start_time: fullDay ? null : startTime,
        end_time: fullDay ? null : endTime,
        reason,
      }),
    });
    setSaving(false);
    setDate("");
    setReason("");
    load();
  };

  const remove = async (id: number) => {
    await fetch(`/api/closures/${id}`, { method: "DELETE" });
    load();
  };

  return (
    <div>
      <h1 className="font-display text-3xl mb-8">Closures</h1>

      <div className="rounded-2xl border p-5 mb-8 max-w-lg" style={{ borderColor: "var(--coffee-light)", background: "white" }}>
        <h2 className="font-medium mb-4">Add closure</h2>
        <div className="space-y-3">
          <div>
            <label className="block text-xs font-medium mb-1 opacity-70">Date</label>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="rounded-lg border px-3 py-2 text-sm w-full"
              style={{ borderColor: "var(--coffee-light)" }}
            />
          </div>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={fullDay} onChange={(e) => setFullDay(e.target.checked)} />
            Full day closed
          </label>
          {!fullDay && (
            <div className="flex items-center gap-2">
              <input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="rounded-lg border px-2 py-1.5 text-sm"
                style={{ borderColor: "var(--coffee-light)" }}
              />
              <span className="text-sm opacity-50">to</span>
              <input
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="rounded-lg border px-2 py-1.5 text-sm"
                style={{ borderColor: "var(--coffee-light)" }}
              />
            </div>
          )}
          <div>
            <label className="block text-xs font-medium mb-1 opacity-70">Reason (optional)</label>
            <input
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="rounded-lg border px-3 py-2 text-sm w-full"
              style={{ borderColor: "var(--coffee-light)" }}
              placeholder="e.g. Eid holiday"
            />
          </div>
        </div>
        <button
          onClick={create}
          disabled={saving || !date}
          className="mt-4 rounded-full px-5 py-2.5 text-white text-sm font-semibold cursor-pointer disabled:opacity-50"
          style={{ background: "var(--coffee)" }}
        >
          Add closure
        </button>
      </div>

      <h2 className="font-medium mb-3">Upcoming & recent</h2>
      <div className="space-y-2 max-w-lg">
        {closures.length === 0 && <p className="text-sm opacity-50">No closures configured.</p>}
        {closures.map((c) => (
          <div
            key={c.id}
            className="flex items-center justify-between rounded-xl border px-4 py-3"
            style={{ borderColor: "var(--coffee-light)", background: "white" }}
          >
            <div className="text-sm">
              <p className="font-medium">
                {c.date} {c.full_day ? "— Full day" : `— ${c.start_time}–${c.end_time}`}
              </p>
              {c.reason && <p className="opacity-60">{c.reason}</p>}
            </div>
            <button onClick={() => remove(c.id)} className="text-xs opacity-50 hover:opacity-100 cursor-pointer">
              remove
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
