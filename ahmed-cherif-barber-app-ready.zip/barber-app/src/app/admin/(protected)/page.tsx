"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

interface Summary {
  today: string;
  total: number;
  confirmed: number;
  completed: number;
  cancelled: number;
  no_shows: number;
  revenue: number;
  totalCustomers: number;
  upcomingToday: Array<{
    id: number;
    start_time: string;
    service_name_en: string;
    customer_name: string;
    customer_phone: string;
  }>;
}

export default function AdminDashboardPage() {
  const [summary, setSummary] = useState<Summary | null>(null);

  useEffect(() => {
    fetch("/api/dashboard/summary")
      .then((r) => r.json())
      .then(setSummary)
      .catch(() => {});
  }, []);

  return (
    <div>
      <h1 className="font-display text-3xl mb-1">Dashboard</h1>
      <p className="text-sm opacity-60 mb-8">{summary?.today}</p>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 mb-10">
        <StatCard label="Today's Appointments" value={summary?.total ?? "—"} />
        <StatCard label="Confirmed" value={summary?.confirmed ?? "—"} color="var(--coffee)" />
        <StatCard label="Completed" value={summary?.completed ?? "—"} color="var(--green)" />
        <StatCard label="No-Shows" value={summary?.no_shows ?? "—"} color="var(--red)" />
        <StatCard
          label="Today's Revenue"
          value={summary ? `${summary.revenue} TND` : "—"}
          color="var(--brass)"
        />
      </div>

      <div className="flex items-center justify-between mb-4">
        <h2 className="font-display text-xl">Upcoming Today</h2>
        <Link href="/admin/appointments" className="text-sm font-medium underline underline-offset-4">
          View all
        </Link>
      </div>

      <div className="rounded-2xl border overflow-hidden" style={{ borderColor: "var(--coffee-light)", background: "white" }}>
        {!summary || summary.upcomingToday.length === 0 ? (
          <p className="p-8 text-center text-sm opacity-50">No appointments today.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-start opacity-50 border-b" style={{ borderColor: "var(--coffee-light)" }}>
                <th className="px-4 py-3 text-start font-medium">Time</th>
                <th className="px-4 py-3 text-start font-medium">Customer</th>
                <th className="px-4 py-3 text-start font-medium">Phone</th>
                <th className="px-4 py-3 text-start font-medium">Service</th>
              </tr>
            </thead>
            <tbody>
              {summary.upcomingToday.map((a) => (
                <tr key={a.id} className="border-b last:border-0" style={{ borderColor: "var(--coffee-light)" }}>
                  <td className="px-4 py-3 font-medium">{a.start_time}</td>
                  <td className="px-4 py-3">{a.customer_name}</td>
                  <td className="px-4 py-3" dir="ltr">
                    {a.customer_phone}
                  </td>
                  <td className="px-4 py-3">{a.service_name_en}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function StatCard({ label, value, color }: { label: string; value: string | number; color?: string }) {
  return (
    <div className="rounded-2xl border p-4" style={{ borderColor: "var(--coffee-light)", background: "white" }}>
      <p className="text-xs opacity-60 mb-1">{label}</p>
      <p className="text-2xl font-semibold" style={{ color: color || "var(--ink)" }}>
        {value}
      </p>
    </div>
  );
}
