"use client";

import { useEffect, useState } from "react";
import type { SettingsMap } from "@/lib/settings";

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<SettingsMap | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch("/api/settings?all=1")
      .then((r) => r.json())
      .then(setSettings);
  }, []);

  const update = (key: keyof SettingsMap, value: string) => {
    setSettings((prev) => (prev ? { ...prev, [key]: value } : prev));
  };

  const save = async () => {
    if (!settings) return;
    setSaving(true);
    await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(settings),
    });
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  if (!settings) return <p className="opacity-50 text-sm">Loading…</p>;

  return (
    <div className="max-w-xl">
      <h1 className="font-display text-3xl mb-8">Settings</h1>

      <Section title="Business info">
        <Field label="Business name (English)">
          <input className="input" value={settings.business_name_en} onChange={(e) => update("business_name_en", e.target.value)} />
        </Field>
        <Field label="Business name (Arabic)">
          <input dir="rtl" className="input" value={settings.business_name_ar} onChange={(e) => update("business_name_ar", e.target.value)} />
        </Field>
        <Field label="Tagline (English)">
          <input className="input" value={settings.tagline_en} onChange={(e) => update("tagline_en", e.target.value)} />
        </Field>
        <Field label="Tagline (Arabic)">
          <input dir="rtl" className="input" value={settings.tagline_ar} onChange={(e) => update("tagline_ar", e.target.value)} />
        </Field>
        <Field label="Phone">
          <input dir="ltr" className="input" value={settings.phone} onChange={(e) => update("phone", e.target.value)} />
        </Field>
        <Field label="Address (English)">
          <input className="input" value={settings.address_en} onChange={(e) => update("address_en", e.target.value)} />
        </Field>
        <Field label="Address (Arabic)">
          <input dir="rtl" className="input" value={settings.address_ar} onChange={(e) => update("address_ar", e.target.value)} />
        </Field>
        <Field label="Google Maps URL">
          <input dir="ltr" className="input" value={settings.google_maps_url} onChange={(e) => update("google_maps_url", e.target.value)} />
        </Field>
      </Section>

      <Section title="Booking policy">
        <Field label="Cancellation window (hours)">
          <input
            type="number"
            className="input"
            value={settings.cancellation_window_hours}
            onChange={(e) => update("cancellation_window_hours", e.target.value)}
          />
        </Field>
        <Field label="Slot interval (minutes)">
          <input
            type="number"
            className="input"
            value={settings.slot_interval_minutes}
            onChange={(e) => update("slot_interval_minutes", e.target.value)}
          />
        </Field>
      </Section>

      <Section title="Currency">
        <Field label="Currency code">
          <input className="input" value={settings.currency} onChange={(e) => update("currency", e.target.value)} />
        </Field>
        <Field label="Currency (Arabic)">
          <input dir="rtl" className="input" value={settings.currency_ar} onChange={(e) => update("currency_ar", e.target.value)} />
        </Field>
      </Section>

      <button
        onClick={save}
        disabled={saving}
        className="rounded-full px-6 py-3 text-white font-semibold cursor-pointer disabled:opacity-50"
        style={{ background: "var(--coffee)" }}
      >
        {saving ? "Saving…" : "Save settings"}
      </button>
      {saved && <span className="ms-3 text-sm" style={{ color: "var(--green)" }}>Saved ✓</span>}

      <style jsx global>{`
        .input {
          width: 100%;
          border: 1px solid var(--coffee-light);
          border-radius: 8px;
          padding: 8px 12px;
          font-size: 14px;
        }
      `}</style>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border p-5 mb-6" style={{ borderColor: "var(--coffee-light)", background: "white" }}>
      <h2 className="font-medium mb-4">{title}</h2>
      <div className="space-y-3">{children}</div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-xs font-medium mb-1 opacity-70">{label}</span>
      {children}
    </label>
  );
}
