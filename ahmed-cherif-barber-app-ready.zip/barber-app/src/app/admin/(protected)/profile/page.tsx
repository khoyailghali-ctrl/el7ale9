"use client";

import { useEffect, useState } from "react";

export default function ProfilePage() {
  const [email, setEmail] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [msg, setMsg] = useState<{ text: string; ok: boolean } | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => setEmail(d.admin?.email || ""));
  }, []);

  const save = async () => {
    setMsg(null);
    if (newPassword !== confirm) {
      setMsg({ text: "The two new passwords do not match.", ok: false });
      return;
    }
    setSaving(true);
    const res = await fetch("/api/auth/password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ currentPassword, newPassword, newEmail: email }),
    });
    const data = await res.json();
    setSaving(false);
    if (res.ok) {
      setMsg({ text: "Saved. Use the new details next time you log in.", ok: true });
      setCurrentPassword("");
      setNewPassword("");
      setConfirm("");
    } else if (data.error === "wrong_current_password") {
      setMsg({ text: "Current password is wrong.", ok: false });
    } else if (data.error === "email_taken") {
      setMsg({ text: "That email is already used.", ok: false });
    } else {
      setMsg({ text: data.error || "Could not save.", ok: false });
    }
  };

  const input = "w-full rounded-lg border px-3 py-2 text-sm";
  const border = { borderColor: "var(--coffee-light)" };

  return (
    <div className="max-w-md">
      <h1 className="font-display text-3xl mb-2">Profile</h1>
      <p className="text-sm opacity-60 mb-8">Change your login email and password. Do this before going public.</p>
      <div className="rounded-2xl border p-5 space-y-4" style={{ ...border, background: "white" }}>
        <label className="block">
          <span className="block text-xs font-medium mb-1 opacity-70">Login email</span>
          <input dir="ltr" type="email" className={input} style={border} value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <label className="block">
          <span className="block text-xs font-medium mb-1 opacity-70">Current password</span>
          <input dir="ltr" type="password" className={input} style={border} value={currentPassword} onChange={(e) => setCurrentPassword(e.target.value)} />
        </label>
        <label className="block">
          <span className="block text-xs font-medium mb-1 opacity-70">New password (10+ characters, letters and numbers)</span>
          <input dir="ltr" type="password" className={input} style={border} value={newPassword} onChange={(e) => setNewPassword(e.target.value)} />
        </label>
        <label className="block">
          <span className="block text-xs font-medium mb-1 opacity-70">Repeat new password</span>
          <input dir="ltr" type="password" className={input} style={border} value={confirm} onChange={(e) => setConfirm(e.target.value)} />
        </label>
        {msg && (
          <p className="text-sm rounded-lg px-3 py-2" style={{ background: msg.ok ? "rgba(63,107,74,0.12)" : "rgba(165,67,58,0.1)", color: msg.ok ? "var(--green)" : "var(--red)" }}>
            {msg.text}
          </p>
        )}
        <button
          onClick={save}
          disabled={saving || !currentPassword || !newPassword}
          className="w-full rounded-lg py-2.5 text-white font-semibold cursor-pointer disabled:opacity-50"
          style={{ background: "var(--coffee)" }}
        >
          {saving ? "Saving…" : "Save"}
        </button>
      </div>
    </div>
  );
}
