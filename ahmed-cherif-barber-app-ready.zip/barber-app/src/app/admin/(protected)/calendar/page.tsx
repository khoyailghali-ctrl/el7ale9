"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import type { AppointmentWithCustomer, AppointmentStatus } from "@/lib/types";

const STATUS_COLORS: Record<AppointmentStatus, string> = {
  CONFIRMED: "var(--coffee)",
  COMPLETED: "var(--green)",
  CANCELLED: "#948a76",
  NO_SHOW: "var(--red)",
};

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function addDays(dateStr: string, n: number) {
  const d = new Date(dateStr + "T00:00:00");
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

export default function AdminCalendarPage() {
  const [date, setDate] = useState(todayStr());
  const [rows, setRows] = useState<AppointmentWithCustomer[]>([]);
  const [loading, setLoading] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    fetch(`/api/appointments?date=${date}`)
      .then((r) => r.json())
      .then((d) => setRows(Array.isArray(d) ? d : []))
      .finally(() => setLoading(false));
  }, [date]);

  useEffect(() => {
    load();
  }, [load]);

  const dObj = new Date(date + "T00:00:00");
  const weekday = dObj.toLocaleDateString("en-US", { weekday: "long" });
  const formatted = dObj.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });

  const activeRows = rows.filter((r) => r.status !== "CANCELLED");

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="font-display text-3xl">Calendar</h1>
        <Link href="/admin/appointments" className="text-sm underline underline-offset-4">
          List view
        </Link>
      </div>

      <div className="flex items-center gap-3 mb-8">
        <button
          onClick={() => setDate(addDays(date, -1))}
          className="rounded-full h-9 w-9 border cursor-pointer"
          style={{ borderColor: "var(--coffee-light)" }}
        >
          ←
        </button>
        <div className="text-center flex-1">
          <p className="font-display text-xl">{weekday}</p>
          <p className="text-sm opacity-60">{formatted}</p>
        </div>
        <button
          onClick={() => setDate(addDays(date, 1))}
          className="rounded-full h-9 w-9 border cursor-pointer"
          style={{ borderColor: "var(--coffee-light)" }}
        >
          →
        </button>
      </div>
      <div className="flex justify-center mb-8">
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="rounded-lg border px-3 py-2 text-sm"
          style={{ borderColor: "var(--coffee-light)" }}
        />
      </div>

      <div className="relative rounded-2xl border p-4" style={{ borderColor: "var(--coffee-light)", background: "white" }}>
        {!loading && activeRows.length === 0 && (
          <p className="text-center py-10 text-sm opacity-50">No appointments this day.</p>
        )}
        <div className="space-y-2">
          {activeRows
            .sort((a, b) => a.start_time.localeCompare(b.start_time))
            .map((a) => (
              <div
                key={a.id}
                className="flex items-center gap-4 rounded-xl px-4 py-3"
                style={{ background: "var(--paper-warm)" }}
              >
                <div className="w-16 shrink-0 font-semibold text-sm">{a.start_time}</div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">{a.customer_name}</p>
                  <p className="text-xs opacity-60 truncate">
                    {a.service_name_en} · {a.customer_phone}
                  </p>
                </div>
                <span
                  className="text-xs font-semibold px-2 py-0.5 rounded-full shrink-0"
                  style={{ color: STATUS_COLORS[a.status], background: `${STATUS_COLORS[a.status]}1a` }}
                >
                  {a.status}
                </span>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}
