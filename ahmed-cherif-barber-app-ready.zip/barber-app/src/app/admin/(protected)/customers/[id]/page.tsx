"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import type { Appointment, AppointmentStatus, Customer } from "@/lib/types";

const STATUS_COLORS: Record<AppointmentStatus, string> = {
  CONFIRMED: "var(--coffee)",
  COMPLETED: "var(--green)",
  CANCELLED: "#948a76",
  NO_SHOW: "var(--red)",
};

export default function CustomerDetailPage() {
  const params = useParams();
  const id = params.id as string;
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [appointments, setAppointments] = useState<Appointment[]>([]);

  useEffect(() => {
    fetch(`/api/customers/${id}`)
      .then((r) => r.json())
      .then((d) => {
        setCustomer(d.customer || null);
        setAppointments(d.appointments || []);
      });
  }, [id]);

  const totalSpent = appointments
    .filter((a) => a.status === "COMPLETED")
    .reduce((sum, a) => sum + a.price_at_booking, 0);

  return (
    <div>
      <Link href="/admin/customers" className="text-sm underline underline-offset-4 mb-6 inline-block">
        ← All customers
      </Link>
      {customer && (
        <>
          <h1 className="font-display text-3xl mb-1">{customer.name}</h1>
          <p className="opacity-60 mb-6" dir="ltr">
            {customer.phone}
          </p>

          <div className="grid grid-cols-3 gap-4 mb-8 max-w-md">
            <Stat label="Appointments" value={appointments.length} />
            <Stat label="Completed" value={appointments.filter((a) => a.status === "COMPLETED").length} />
            <Stat label="Spent" value={`${totalSpent} TND`} />
          </div>
        </>
      )}

      <h2 className="font-display text-xl mb-4">History</h2>
      <div className="rounded-2xl border overflow-hidden" style={{ borderColor: "var(--coffee-light)", background: "white" }}>
        {appointments.length === 0 ? (
          <p className="p-8 text-center text-sm opacity-50">No appointments yet.</p>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="text-start opacity-50 border-b" style={{ borderColor: "var(--coffee-light)" }}>
                <th className="px-4 py-3 text-start font-medium">Date</th>
                <th className="px-4 py-3 text-start font-medium">Time</th>
                <th className="px-4 py-3 text-start font-medium">Service</th>
                <th className="px-4 py-3 text-start font-medium">Price</th>
                <th className="px-4 py-3 text-start font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {appointments.map((a) => (
                <tr key={a.id} className="border-b last:border-0" style={{ borderColor: "var(--coffee-light)" }}>
                  <td className="px-4 py-3">{a.date}</td>
                  <td className="px-4 py-3">{a.start_time}</td>
                  <td className="px-4 py-3">{a.service_name_en}</td>
                  <td className="px-4 py-3">{a.price_at_booking} TND</td>
                  <td className="px-4 py-3">
                    <span
                      className="text-xs font-semibold px-2 py-0.5 rounded-full"
                      style={{ color: STATUS_COLORS[a.status], background: `${STATUS_COLORS[a.status]}1a` }}
                    >
                      {a.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-xl border p-3" style={{ borderColor: "var(--coffee-light)" }}>
      <p className="text-xs opacity-60">{label}</p>
      <p className="text-lg font-semibold">{value}</p>
    </div>
  );
}
