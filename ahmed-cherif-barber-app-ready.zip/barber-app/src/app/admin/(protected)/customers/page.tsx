"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

interface CustomerRow {
  id: number;
  name: string;
  phone: string;
  total_appointments: number;
  completed: number;
  cancelled: number;
  no_shows: number;
  total_spent: number;
  last_appointment: string | null;
  next_appointment: string | null;
}

export default function AdminCustomersPage() {
  const [rows, setRows] = useState<CustomerRow[]>([]);
  const [query, setQuery] = useState("");

  useEffect(() => {
    fetch("/api/customers")
      .then((r) => r.json())
      .then((d) => setRows(Array.isArray(d) ? d : []));
  }, []);

  const filtered = rows.filter(
    (r) =>
      r.name.toLowerCase().includes(query.toLowerCase()) ||
      r.phone.includes(query)
  );

  return (
    <div>
      <h1 className="font-display text-3xl mb-6">Customers</h1>
      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search name or phone…"
        className="rounded-lg border px-4 py-2.5 text-sm mb-6 w-full max-w-sm"
        style={{ borderColor: "var(--coffee-light)" }}
      />
      <div className="rounded-2xl border overflow-x-auto" style={{ borderColor: "var(--coffee-light)", background: "white" }}>
        <table className="w-full text-sm min-w-[720px]">
          <thead>
            <tr className="text-start opacity-50 border-b" style={{ borderColor: "var(--coffee-light)" }}>
              <th className="px-4 py-3 text-start font-medium">Name</th>
              <th className="px-4 py-3 text-start font-medium">Phone</th>
              <th className="px-4 py-3 text-start font-medium">Total</th>
              <th className="px-4 py-3 text-start font-medium">Completed</th>
              <th className="px-4 py-3 text-start font-medium">No-shows</th>
              <th className="px-4 py-3 text-start font-medium">Spent</th>
              <th className="px-4 py-3 text-start font-medium">Next</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((c) => (
              <tr
                key={c.id}
                className="border-b last:border-0 cursor-pointer hover:bg-[var(--paper-warm)]"
                style={{ borderColor: "var(--coffee-light)" }}
              >
                <td className="px-4 py-3">
                  <Link href={`/admin/customers/${c.id}`} className="font-medium hover:underline">
                    {c.name}
                  </Link>
                </td>
                <td className="px-4 py-3" dir="ltr">
                  {c.phone}
                </td>
                <td className="px-4 py-3">{c.total_appointments}</td>
                <td className="px-4 py-3">{c.completed}</td>
                <td className="px-4 py-3" style={{ color: c.no_shows > 0 ? "var(--red)" : undefined }}>
                  {c.no_shows}
                </td>
                <td className="px-4 py-3">{c.total_spent} TND</td>
                <td className="px-4 py-3 opacity-70">{c.next_appointment || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
