"use client";

import { useEffect, useState, useCallback } from "react";
import type { AppointmentWithCustomer, AppointmentStatus, Service } from "@/lib/types";

const STATUS_COLORS: Record<AppointmentStatus, string> = {
  CONFIRMED: "var(--coffee)",
  COMPLETED: "var(--green)",
  CANCELLED: "#948a76",
  NO_SHOW: "var(--red)",
};

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

export default function AdminAppointmentsPage() {
  const [date, setDate] = useState(todayStr());
  const [status, setStatus] = useState<string>("");
  const [rows, setRows] = useState<AppointmentWithCustomer[]>([]);
  const [loading, setLoading] = useState(false);
  const [editing, setEditing] = useState<AppointmentWithCustomer | null>(null);
  const [services, setServices] = useState<Service[]>([]);
  const [showCreate, setShowCreate] = useState(false);

  const load = useCallback(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (date) params.set("date", date);
    if (status) params.set("status", status);
    fetch(`/api/appointments?${params}`)
      .then((r) => r.json())
      .then((d) => setRows(Array.isArray(d) ? d : []))
      .finally(() => setLoading(false));
  }, [date, status]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    fetch("/api/services?all=1")
      .then((r) => r.json())
      .then((d) => setServices(Array.isArray(d) ? d : []));
  }, []);

  const updateStatus = async (id: number, newStatus: AppointmentStatus) => {
    await fetch(`/api/appointments/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: newStatus }),
    });
    load();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="font-display text-3xl">Appointments</h1>
        <button
          onClick={() => setShowCreate(true)}
          className="rounded-full px-5 py-2.5 text-white text-sm font-semibold cursor-pointer"
          style={{ background: "var(--coffee)" }}
        >
          + New appointment
        </button>
      </div>

      <div className="flex items-center gap-3 mb-6 flex-wrap">
        <input
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
          className="rounded-lg border px-3 py-2 text-sm"
          style={{ borderColor: "var(--coffee-light)" }}
        />
        <button
          onClick={() => setDate("")}
          className="text-xs opacity-60 underline cursor-pointer"
        >
          clear date
        </button>
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="rounded-lg border px-3 py-2 text-sm"
          style={{ borderColor: "var(--coffee-light)" }}
        >
          <option value="">All statuses</option>
          <option value="CONFIRMED">Confirmed</option>
          <option value="COMPLETED">Completed</option>
          <option value="CANCELLED">Cancelled</option>
          <option value="NO_SHOW">No-show</option>
        </select>
      </div>

      <div className="rounded-2xl border overflow-x-auto" style={{ borderColor: "var(--coffee-light)", background: "white" }}>
        <table className="w-full text-sm min-w-[720px]">
          <thead>
            <tr className="text-start opacity-50 border-b" style={{ borderColor: "var(--coffee-light)" }}>
              <th className="px-4 py-3 text-start font-medium">Date</th>
              <th className="px-4 py-3 text-start font-medium">Time</th>
              <th className="px-4 py-3 text-start font-medium">Customer</th>
              <th className="px-4 py-3 text-start font-medium">Phone</th>
              <th className="px-4 py-3 text-start font-medium">Service</th>
              <th className="px-4 py-3 text-start font-medium">Status</th>
              <th className="px-4 py-3 text-start font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {!loading && rows.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-8 text-center opacity-50">
                  No appointments found.
                </td>
              </tr>
            )}
            {rows.map((a) => (
              <tr key={a.id} className="border-b last:border-0" style={{ borderColor: "var(--coffee-light)" }}>
                <td className="px-4 py-3">{a.date}</td>
                <td className="px-4 py-3">{a.start_time}</td>
                <td className="px-4 py-3">{a.customer_name}</td>
                <td className="px-4 py-3" dir="ltr">
                  {a.customer_phone}
                </td>
                <td className="px-4 py-3">{a.service_name_en}</td>
                <td className="px-4 py-3">
                  <span
                    className="text-xs font-semibold px-2 py-0.5 rounded-full"
                    style={{ color: STATUS_COLORS[a.status], background: `${STATUS_COLORS[a.status]}1a` }}
                  >
                    {a.status}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2 flex-wrap">
                    <button onClick={() => setEditing(a)} className="text-xs underline cursor-pointer">
                      Edit
                    </button>
                    {a.status === "CONFIRMED" && (
                      <>
                        <button
                          onClick={() => updateStatus(a.id, "COMPLETED")}
                          className="text-xs cursor-pointer"
                          style={{ color: "var(--green)" }}
                        >
                          Complete
                        </button>
                        <button
                          onClick={() => updateStatus(a.id, "NO_SHOW")}
                          className="text-xs cursor-pointer"
                          style={{ color: "var(--red)" }}
                        >
                          No-show
                        </button>
                        <button
                          onClick={() => updateStatus(a.id, "CANCELLED")}
                          className="text-xs opacity-60 cursor-pointer"
                        >
                          Cancel
                        </button>
                      </>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editing && (
        <EditModal
          appointment={editing}
          services={services}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            load();
          }}
        />
      )}
      {showCreate && (
        <CreateModal
          services={services}
          onClose={() => setShowCreate(false)}
          onCreated={() => {
            setShowCreate(false);
            load();
          }}
        />
      )}
    </div>
  );
}

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-2xl p-6 max-h-[85vh] overflow-y-auto"
        style={{ background: "white" }}
      >
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-display text-xl">{title}</h2>
          <button onClick={onClose} className="opacity-50 hover:opacity-100 cursor-pointer">
            ✕
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

function EditModal({
  appointment,
  services,
  onClose,
  onSaved,
}: {
  appointment: AppointmentWithCustomer;
  services: Service[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const [date, setDate] = useState(appointment.date);
  const [startTime, setStartTime] = useState(appointment.start_time);
  const [serviceId, setServiceId] = useState(appointment.service_id);
  const [notes, setNotes] = useState(appointment.notes || "");
  const [name, setName] = useState(appointment.customer_name);
  const [phone, setPhone] = useState(appointment.customer_phone);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    setError(null);
    const res = await fetch(`/api/appointments/${appointment.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        date,
        startTime,
        serviceId,
        notes,
        customerName: name,
        customerPhone: phone,
      }),
    });
    setSaving(false);
    if (!res.ok) {
      const data = await res.json();
      setError(data.error === "slot_taken" ? "That time is already booked." : "Could not save changes.");
      return;
    }
    onSaved();
  };

  return (
    <Modal title="Edit appointment" onClose={onClose}>
      {error && (
        <p className="text-sm rounded-lg px-3 py-2 mb-3" style={{ background: "rgba(165,67,58,0.1)", color: "var(--red)" }}>
          {error}
        </p>
      )}
      <div className="space-y-3">
        <Field label="Customer name">
          <input value={name} onChange={(e) => setName(e.target.value)} className="input" />
        </Field>
        <Field label="Phone">
          <input dir="ltr" value={phone} onChange={(e) => setPhone(e.target.value)} className="input" />
        </Field>
        <Field label="Service">
          <select value={serviceId} onChange={(e) => setServiceId(Number(e.target.value))} className="input">
            {services.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name_en} ({s.duration_minutes}min)
              </option>
            ))}
          </select>
        </Field>
        <Field label="Date">
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input" />
        </Field>
        <Field label="Start time">
          <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} className="input" />
        </Field>
        <Field label="Notes">
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} className="input" rows={2} />
        </Field>
      </div>
      <button
        onClick={save}
        disabled={saving}
        className="w-full mt-5 rounded-lg py-2.5 text-white font-semibold cursor-pointer disabled:opacity-50"
        style={{ background: "var(--coffee)" }}
      >
        {saving ? "Saving…" : "Save changes"}
      </button>
      <style jsx>{`
        .input {
          width: 100%;
          border: 1px solid var(--coffee-light);
          border-radius: 8px;
          padding: 8px 12px;
          font-size: 14px;
        }
      `}</style>
    </Modal>
  );
}

function CreateModal({
  services,
  onClose,
  onCreated,
}: {
  services: Service[];
  onClose: () => void;
  onCreated: () => void;
}) {
  const [serviceId, setServiceId] = useState(services[0]?.id || 0);
  const [date, setDate] = useState(todayStr());
  const [startTime, setStartTime] = useState("10:00");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    setSaving(true);
    setError(null);
    const res = await fetch("/api/appointments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ serviceId, date, startTime, name, phone }),
    });
    setSaving(false);
    if (!res.ok) {
      const data = await res.json();
      setError(data.error === "slot_taken" ? "That time is already booked." : "Could not create appointment.");
      return;
    }
    onCreated();
  };

  return (
    <Modal title="New appointment" onClose={onClose}>
      {error && (
        <p className="text-sm rounded-lg px-3 py-2 mb-3" style={{ background: "rgba(165,67,58,0.1)", color: "var(--red)" }}>
          {error}
        </p>
      )}
      <div className="space-y-3">
        <Field label="Customer name">
          <input value={name} onChange={(e) => setName(e.target.value)} className="input" />
        </Field>
        <Field label="Phone">
          <input dir="ltr" value={phone} onChange={(e) => setPhone(e.target.value)} className="input" />
        </Field>
        <Field label="Service">
          <select value={serviceId} onChange={(e) => setServiceId(Number(e.target.value))} className="input">
            {services.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name_en} ({s.duration_minutes}min)
              </option>
            ))}
          </select>
        </Field>
        <Field label="Date">
          <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="input" />
        </Field>
        <Field label="Start time">
          <input type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} className="input" />
        </Field>
      </div>
      <button
        onClick={submit}
        disabled={saving || !name || !phone}
        className="w-full mt-5 rounded-lg py-2.5 text-white font-semibold cursor-pointer disabled:opacity-50"
        style={{ background: "var(--coffee)" }}
      >
        {saving ? "Creating…" : "Create appointment"}
      </button>
      <style jsx>{`
        .input {
          width: 100%;
          border: 1px solid var(--coffee-light);
          border-radius: 8px;
          padding: 8px 12px;
          font-size: 14px;
        }
      `}</style>
    </Modal>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="block text-xs font-medium mb-1 opacity-70">{label}</span>
      {children}
    </label>
  );
}
