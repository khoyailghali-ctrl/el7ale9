"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Logo } from "@/components/Logo";

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      if (!res.ok) {
        const data = await res.json();
        setError(
          data.error === "too_many_attempts"
            ? "Too many attempts. Try again later."
            : "Invalid email or password."
        );
        return;
      }
      router.push("/admin");
      router.refresh();
    } catch {
      setError("Something went wrong. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center px-5"
      style={{ background: "var(--ink)" }}
    >
      <form
        onSubmit={submit}
        className="w-full max-w-sm rounded-2xl p-8 shadow-2xl"
        style={{ background: "var(--paper)" }}
      >
        <div className="flex flex-col items-center mb-8">
          <Logo size={60} />
          <h1 className="font-display text-2xl mt-3">Admin Login</h1>
          <p className="text-xs opacity-50 mt-1">Ahmed Cherif — Management</p>
        </div>

        {error && (
          <p
            className="text-sm rounded-lg px-3 py-2 mb-4"
            style={{ background: "rgba(165,67,58,0.1)", color: "var(--red)" }}
          >
            {error}
          </p>
        )}

        <label className="block text-sm font-medium mb-1.5">Email</label>
        <input
          type="email"
          dir="ltr"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          className="w-full rounded-lg border px-4 py-3 mb-4 focus:outline-none"
          style={{ borderColor: "var(--coffee-light)" }}
          placeholder="admin@ahmedcherif.tn"
        />

        <label className="block text-sm font-medium mb-1.5">Password</label>
        <input
          type="password"
          dir="ltr"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          className="w-full rounded-lg border px-4 py-3 mb-6 focus:outline-none"
          style={{ borderColor: "var(--coffee-light)" }}
        />

        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-lg py-3 text-white font-semibold cursor-pointer disabled:opacity-50"
          style={{ background: "var(--coffee)" }}
        >
          {loading ? "…" : "Log in"}
        </button>

        <p className="text-xs opacity-40 mt-6 text-center">
          Demo: admin@ahmedcherif.tn / Ahmed@12345
        </p>
      </form>
    </div>
  );
}
