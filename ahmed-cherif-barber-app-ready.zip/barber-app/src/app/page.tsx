import { getSettings } from "@/lib/settings";
import { db } from "@/lib/db";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { AnnouncementBanner } from "@/components/AnnouncementBanner";
import { HomeContent } from "@/components/HomeContent";
import type { Service } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const settings = getSettings();
  // node:sqlite rows are null-prototype objects, which the Server->Client
  // Component boundary rejects — plain-serialize before passing as props.
  const services = JSON.parse(
    JSON.stringify(
      db.prepare("SELECT * FROM services WHERE active = 1 ORDER BY sort_order, id").all()
    )
  ) as Service[];

  return (
    <>
      <Header settings={settings} />
      <AnnouncementBanner />
      <main className="flex-1">
        <HomeContent settings={settings} services={services} />
      </main>
      <Footer settings={settings} />
    </>
  );
}
