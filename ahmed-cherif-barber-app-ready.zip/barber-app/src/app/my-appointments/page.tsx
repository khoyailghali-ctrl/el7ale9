import { getSettings } from "@/lib/settings";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { MyAppointmentsFlow } from "@/components/MyAppointmentsFlow";

export const dynamic = "force-dynamic";

export default async function MyAppointmentsPage() {
  const settings = getSettings();
  return (
    <>
      <Header settings={settings} />
      <main className="flex-1">
        <MyAppointmentsFlow />
      </main>
      <Footer settings={settings} />
    </>
  );
}
