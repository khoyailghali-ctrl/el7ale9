import { getSettings } from "@/lib/settings";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { BookingFlow } from "@/components/BookingFlow";

export const dynamic = "force-dynamic";

export default async function BookPage() {
  const settings = getSettings();
  return (
    <>
      <Header settings={settings} />
      <main className="flex-1">
        <BookingFlow />
      </main>
      <Footer settings={settings} />
    </>
  );
}
