import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, serverError } from "@/lib/api-helpers";

export async function GET() {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  try {
    const rows = db
      .prepare("SELECT * FROM notifications WHERE audience = 'ADMIN' ORDER BY id DESC LIMIT 30")
      .all();
    const unread = db
      .prepare("SELECT COUNT(*) as n FROM notifications WHERE audience = 'ADMIN' AND read = 0")
      .get() as { n: number };
    return NextResponse.json({ notifications: rows, unread: unread.n });
  } catch (err) {
    return serverError(err);
  }
}

export async function PATCH(req: NextRequest) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  try {
    db.prepare("UPDATE notifications SET read = 1 WHERE audience = 'ADMIN'").run();
    return NextResponse.json({ ok: true });
  } catch (err) {
    return serverError(err);
  }
}
