import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, badRequest, serverError } from "@/lib/api-helpers";
import { z } from "zod";

const PatchSchema = z.object({
  name_en: z.string().min(1).optional(),
  name_ar: z.string().min(1).optional(),
  description_en: z.string().optional(),
  description_ar: z.string().optional(),
  price: z.number().positive().optional(),
  duration_minutes: z.number().int().positive().optional(),
  active: z.boolean().optional(),
  sort_order: z.number().int().optional(),
});

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  const { id } = await ctx.params;
  try {
    const body = PatchSchema.parse(await req.json());
    const fields = Object.entries(body);
    if (fields.length === 0) return badRequest("No fields to update");
    const setClause = fields.map(([k]) => `${k} = ?`).join(", ");
    const values: (string | number)[] = fields.map(([k, v]) =>
      k === "active" ? (v ? 1 : 0) : (v as string | number)
    );
    db.prepare(`UPDATE services SET ${setClause} WHERE id = ?`).run(...values, id);
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof z.ZodError) return badRequest(err.issues.map((i) => i.message).join(", "));
    return serverError(err);
  }
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  const { id } = await ctx.params;
  try {
    // Soft delete: deactivate rather than hard-delete, since past appointments
    // reference this service's name/price snapshot, not a live join.
    db.prepare("UPDATE services SET active = 0 WHERE id = ?").run(id);
    return NextResponse.json({ ok: true });
  } catch (err) {
    return serverError(err);
  }
}
