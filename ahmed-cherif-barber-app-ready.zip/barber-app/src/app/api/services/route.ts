import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, badRequest, serverError } from "@/lib/api-helpers";
import { z } from "zod";

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const includeInactive = url.searchParams.get("all") === "1";
  try {
    if (includeInactive) {
      const { admin, res } = await requireAdmin();
      if (!admin) return res;
      const rows = db.prepare("SELECT * FROM services ORDER BY sort_order, id").all();
      return NextResponse.json(rows);
    }
    const rows = db
      .prepare("SELECT * FROM services WHERE active = 1 ORDER BY sort_order, id")
      .all();
    return NextResponse.json(rows);
  } catch (err) {
    return serverError(err);
  }
}

const ServiceSchema = z.object({
  name_en: z.string().min(1),
  name_ar: z.string().min(1),
  description_en: z.string().default(""),
  description_ar: z.string().default(""),
  price: z.number().positive(),
  duration_minutes: z.number().int().positive(),
  active: z.boolean().default(true),
  sort_order: z.number().int().default(0),
});

export async function POST(req: NextRequest) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  try {
    const body = ServiceSchema.parse(await req.json());
    const info = db
      .prepare(
        `INSERT INTO services (name_en, name_ar, description_en, description_ar, price, duration_minutes, active, sort_order)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(
        body.name_en,
        body.name_ar,
        body.description_en,
        body.description_ar,
        body.price,
        body.duration_minutes,
        body.active ? 1 : 0,
        body.sort_order
      );
    return NextResponse.json({ id: Number(info.lastInsertRowid) }, { status: 201 });
  } catch (err) {
    if (err instanceof z.ZodError) return badRequest(err.issues.map((i) => i.message).join(", "));
    return serverError(err);
  }
}
