import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { badRequest } from "@/lib/api-helpers";

// Simple in-memory rate limit per phone/IP to slow down enumeration attempts.
const attempts = new Map<string, { count: number; resetAt: number }>();
const WINDOW_MS = 60_000;
const MAX_ATTEMPTS = 10;

function isRateLimited(key: string) {
  const now = Date.now();
  const entry = attempts.get(key);
  if (!entry || now > entry.resetAt) {
    attempts.set(key, { count: 1, resetAt: now + WINDOW_MS });
    return false;
  }
  entry.count += 1;
  return entry.count > MAX_ATTEMPTS;
}

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const phoneRaw = url.searchParams.get("phone");
  if (!phoneRaw) return badRequest("Missing phone");
  const phone = phoneRaw.replace(/[\s-]/g, "");

  const ip = req.headers.get("x-forwarded-for") || "local";
  if (isRateLimited(`${ip}:${phone}`)) {
    return NextResponse.json({ error: "rate_limited" }, { status: 429 });
  }

  const customer = db.prepare("SELECT id, name, phone FROM customers WHERE phone = ?").get(phone) as
    | { id: number; name: string; phone: string }
    | undefined;

  if (!customer) return NextResponse.json({ customer: null, appointments: [] });

  const appointments = db
    .prepare(
      `SELECT * FROM appointments WHERE customer_id = ? ORDER BY date DESC, start_time DESC LIMIT 25`
    )
    .all(customer.id);

  return NextResponse.json({ customer, appointments });
}
