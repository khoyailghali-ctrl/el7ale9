import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { bookAppointment } from "@/lib/availability";
import { requireAdmin, badRequest, serverError } from "@/lib/api-helpers";
import { getCurrentAdmin } from "@/lib/auth";
import { z } from "zod";

const BookingSchema = z.object({
  serviceId: z.number().int().positive(),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  startTime: z.string().regex(/^\d{2}:\d{2}$/),
  name: z.string().trim().min(2).max(100),
  phone: z
    .string()
    .trim()
    .regex(/^[0-9+\s-]{6,20}$/, "Invalid phone number"),
});

function normalizePhone(phone: string) {
  return phone.replace(/[\s-]/g, "");
}

export async function POST(req: NextRequest) {
  try {
    const body = BookingSchema.parse(await req.json());
    const phone = normalizePhone(body.phone);

    // find-or-create customer by phone (phone is the primary identifier)
    let customer = db.prepare("SELECT id FROM customers WHERE phone = ?").get(phone) as
      | { id: number }
      | undefined;

    if (!customer) {
      const info = db
        .prepare("INSERT INTO customers (name, phone) VALUES (?, ?)")
        .run(body.name, phone);
      customer = { id: Number(info.lastInsertRowid) };
    } else {
      // keep the name fresh in case they gave an updated one
      db.prepare("UPDATE customers SET name = ? WHERE id = ?").run(body.name, customer.id);
    }

    // Admins can create a manual appointment even while the shop is toggled
    // "closed" to the public (e.g. a walk-in booked over the phone).
    const admin = await getCurrentAdmin();
    const result = bookAppointment({
      serviceId: body.serviceId,
      date: body.date,
      startTime: body.startTime,
      customerId: customer.id,
      bypassShopOpenCheck: Boolean(admin),
    });

    if (!result.ok) {
      const status = 409;
      const messages: Record<string, string> = {
        SHOP_CLOSED: "shop_closed",
        SLOT_TAKEN: "slot_taken",
        INVALID_SLOT: "invalid_slot",
        SERVICE_NOT_FOUND: "service_not_found",
      };
      return NextResponse.json({ error: messages[result.reason] }, { status });
    }

    return NextResponse.json({ appointmentId: result.appointmentId }, { status: 201 });
  } catch (err) {
    if (err instanceof z.ZodError) return badRequest(err.issues.map((i) => i.message).join(", "));
    return serverError(err);
  }
}

export async function GET(req: NextRequest) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;

  const url = new URL(req.url);
  const date = url.searchParams.get("date");
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");
  const status = url.searchParams.get("status");

  try {
    let query = `
      SELECT a.*, c.name as customer_name, c.phone as customer_phone
      FROM appointments a
      JOIN customers c ON c.id = a.customer_id
      WHERE 1=1
    `;
    const args: (string | number)[] = [];

    if (date) {
      query += " AND a.date = ?";
      args.push(date);
    } else if (from && to) {
      query += " AND a.date BETWEEN ? AND ?";
      args.push(from, to);
    }
    if (status) {
      query += " AND a.status = ?";
      args.push(status);
    }
    query += " ORDER BY a.date DESC, a.start_time DESC";

    const rows = db.prepare(query).all(...args);
    return NextResponse.json(rows);
  } catch (err) {
    return serverError(err);
  }
}
