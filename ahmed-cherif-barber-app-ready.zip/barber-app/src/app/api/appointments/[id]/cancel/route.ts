import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentAdmin } from "@/lib/auth";
import { getSetting } from "@/lib/settings";
import { badRequest, serverError } from "@/lib/api-helpers";
import { z } from "zod";

const Schema = z.object({
  phone: z.string().min(4),
});

export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    const admin = await getCurrentAdmin();
    const appt = db
      .prepare(
        `SELECT a.*, c.phone as customer_phone FROM appointments a
         JOIN customers c ON c.id = a.customer_id WHERE a.id = ?`
      )
      .get(id) as Record<string, unknown> | undefined;
    if (!appt) return NextResponse.json({ error: "not_found" }, { status: 404 });

    if (!admin) {
      const body = Schema.parse(await req.json());
      const phone = body.phone.replace(/[\s-]/g, "");
      if (phone !== appt.customer_phone) {
        return NextResponse.json({ error: "phone_mismatch" }, { status: 403 });
      }

      if (appt.status !== "CONFIRMED") {
        return NextResponse.json({ error: "not_cancellable" }, { status: 409 });
      }

      const windowHours = Number(getSetting("cancellation_window_hours")) || 0;
      const apptDateTime = new Date(`${appt.date}T${appt.start_time}:00`);
      const cutoff = new Date(apptDateTime.getTime() - windowHours * 3600 * 1000);
      if (new Date() > cutoff) {
        return NextResponse.json({ error: "past_cancellation_window" }, { status: 409 });
      }
    }

    db.prepare("UPDATE appointments SET status = 'CANCELLED', updated_at = datetime('now') WHERE id = ?").run(
      id
    );
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof z.ZodError) return badRequest("Invalid request");
    return serverError(err);
  }
}
