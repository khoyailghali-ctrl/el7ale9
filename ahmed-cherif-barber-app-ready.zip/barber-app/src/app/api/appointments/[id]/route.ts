import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, badRequest, serverError } from "@/lib/api-helpers";
import { getService, toMinutes, toHHMM } from "@/lib/availability";
import { z } from "zod";

const PatchSchema = z.object({
  status: z.enum(["CONFIRMED", "COMPLETED", "CANCELLED", "NO_SHOW"]).optional(),
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  startTime: z.string().regex(/^\d{2}:\d{2}$/).optional(),
  serviceId: z.number().int().positive().optional(),
  notes: z.string().optional(),
  customerName: z.string().min(2).optional(),
  customerPhone: z.string().min(6).optional(),
});

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  const { id } = await ctx.params;

  try {
    const body = PatchSchema.parse(await req.json());
    const appt = db.prepare("SELECT * FROM appointments WHERE id = ?").get(id) as
      | Record<string, unknown>
      | undefined;
    if (!appt) return NextResponse.json({ error: "Not found" }, { status: 404 });

    // Reschedule / service change: recompute end_time and check conflicts,
    // admin overrides are still validated server-side against real state.
    if (body.date || body.startTime || body.serviceId) {
      const date = (body.date as string) || (appt.date as string);
      const startTime = (body.startTime as string) || (appt.start_time as string);
      const serviceId = body.serviceId || (appt.service_id as number);
      const service = getService(serviceId);
      if (!service) return badRequest("Service not found");

      const startMin = toMinutes(startTime);
      const endTime = toHHMM(startMin + service.duration_minutes);

      const conflict = db
        .prepare(
          `SELECT id FROM appointments
           WHERE date = ? AND status = 'CONFIRMED' AND id != ?
             AND start_time < ? AND end_time > ?`
        )
        .get(date, id, endTime, startTime);
      if (conflict) return NextResponse.json({ error: "slot_taken" }, { status: 409 });

      db.prepare(
        `UPDATE appointments SET date = ?, start_time = ?, end_time = ?, service_id = ?,
           price_at_booking = ?, service_name_en = ?, service_name_ar = ?, updated_at = datetime('now')
         WHERE id = ?`
      ).run(date, startTime, endTime, serviceId, service.price, service.name_en, service.name_ar, id);
    }

    if (body.status) {
      db.prepare("UPDATE appointments SET status = ?, updated_at = datetime('now') WHERE id = ?").run(
        body.status,
        id
      );
    }

    if (body.notes !== undefined) {
      db.prepare("UPDATE appointments SET notes = ? WHERE id = ?").run(body.notes, id);
    }

    if (body.customerName || body.customerPhone) {
      const customerId = appt.customer_id as number;
      if (body.customerName) {
        db.prepare("UPDATE customers SET name = ? WHERE id = ?").run(body.customerName, customerId);
      }
      if (body.customerPhone) {
        db.prepare("UPDATE customers SET phone = ? WHERE id = ?").run(body.customerPhone, customerId);
      }
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof z.ZodError) return badRequest(err.issues.map((i) => i.message).join(", "));
    return serverError(err);
  }
}
