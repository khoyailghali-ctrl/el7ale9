import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, badRequest, serverError } from "@/lib/api-helpers";
import { z } from "zod";

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const all = url.searchParams.get("all") === "1";
  try {
    if (all) {
      const { admin, res } = await requireAdmin();
      if (!admin) return res;
      return NextResponse.json(db.prepare("SELECT * FROM announcements ORDER BY id DESC").all());
    }
    const today = new Date().toISOString().slice(0, 10);
    const rows = db
      .prepare(
        "SELECT * FROM announcements WHERE active = 1 AND start_date <= ? AND end_date >= ? ORDER BY id DESC"
      )
      .all(today, today);
    return NextResponse.json(rows);
  } catch (err) {
    return serverError(err);
  }
}

const Schema = z.object({
  title_en: z.string().min(1),
  title_ar: z.string().min(1),
  message_en: z.string().min(1),
  message_ar: z.string().min(1),
  start_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  end_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  active: z.boolean().default(true),
});

export async function POST(req: NextRequest) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  try {
    const body = Schema.parse(await req.json());
    const info = db
      .prepare(
        `INSERT INTO announcements (title_en, title_ar, message_en, message_ar, start_date, end_date, active)
         VALUES (?, ?, ?, ?, ?, ?, ?)`
      )
      .run(body.title_en, body.title_ar, body.message_en, body.message_ar, body.start_date, body.end_date, body.active ? 1 : 0);
    return NextResponse.json({ id: Number(info.lastInsertRowid) }, { status: 201 });
  } catch (err) {
    if (err instanceof z.ZodError) return badRequest(err.issues.map((i) => i.message).join(", "));
    return serverError(err);
  }
}
