import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, badRequest, serverError } from "@/lib/api-helpers";
import { z } from "zod";

const Schema = z.object({
  title_en: z.string().min(1).optional(),
  title_ar: z.string().min(1).optional(),
  message_en: z.string().min(1).optional(),
  message_ar: z.string().min(1).optional(),
  start_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  end_date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/).optional(),
  active: z.boolean().optional(),
});

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  const { id } = await ctx.params;
  try {
    const body = Schema.parse(await req.json());
    const fields = Object.entries(body);
    if (fields.length === 0) return badRequest("No fields");
    const setClause = fields.map(([k]) => `${k} = ?`).join(", ");
    const values: (string | number)[] = fields.map(([k, v]) =>
      k === "active" ? (v ? 1 : 0) : (v as string)
    );
    db.prepare(`UPDATE announcements SET ${setClause} WHERE id = ?`).run(...values, id);
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof z.ZodError) return badRequest(err.issues.map((i) => i.message).join(", "));
    return serverError(err);
  }
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  const { id } = await ctx.params;
  try {
    db.prepare("DELETE FROM announcements WHERE id = ?").run(id);
    return NextResponse.json({ ok: true });
  } catch (err) {
    return serverError(err);
  }
}
