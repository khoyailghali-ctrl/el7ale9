import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, serverError } from "@/lib/api-helpers";

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  const { id } = await ctx.params;
  try {
    db.prepare("DELETE FROM closures WHERE id = ?").run(id);
    return NextResponse.json({ ok: true });
  } catch (err) {
    return serverError(err);
  }
}
