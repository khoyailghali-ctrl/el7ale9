import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, badRequest, serverError } from "@/lib/api-helpers";
import { z } from "zod";

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");
  try {
    if (from && to) {
      const rows = db.prepare("SELECT * FROM closures WHERE date BETWEEN ? AND ? ORDER BY date").all(from, to);
      return NextResponse.json(rows);
    }
    const rows = db.prepare("SELECT * FROM closures ORDER BY date DESC LIMIT 100").all();
    return NextResponse.json(rows);
  } catch (err) {
    return serverError(err);
  }
}

const Schema = z.object({
  date: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  full_day: z.boolean(),
  start_time: z.string().regex(/^\d{2}:\d{2}$/).optional().nullable(),
  end_time: z.string().regex(/^\d{2}:\d{2}$/).optional().nullable(),
  reason: z.string().default(""),
});

export async function POST(req: NextRequest) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  try {
    const body = Schema.parse(await req.json());
    if (!body.full_day && (!body.start_time || !body.end_time)) {
      return badRequest("start_time and end_time required for partial closures");
    }
    const info = db
      .prepare(
        "INSERT INTO closures (date, full_day, start_time, end_time, reason) VALUES (?, ?, ?, ?, ?)"
      )
      .run(body.date, body.full_day ? 1 : 0, body.start_time ?? null, body.end_time ?? null, body.reason);
    return NextResponse.json({ id: Number(info.lastInsertRowid) }, { status: 201 });
  } catch (err) {
    if (err instanceof z.ZodError) return badRequest(err.issues.map((i) => i.message).join(", "));
    return serverError(err);
  }
}
