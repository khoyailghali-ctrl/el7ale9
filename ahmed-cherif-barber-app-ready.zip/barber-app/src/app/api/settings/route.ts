import { NextRequest, NextResponse } from "next/server";
import { getSettings, setSettings, DEFAULT_SETTINGS } from "@/lib/settings";
import { requireAdmin, badRequest, serverError } from "@/lib/api-helpers";
import { z } from "zod";

// Subset safe to expose publicly (no internal-only settings currently, but
// keep this explicit allowlist so future admin-only keys don't leak).
const PUBLIC_KEYS = [
  "business_name_en",
  "business_name_ar",
  "tagline_en",
  "tagline_ar",
  "phone",
  "address_en",
  "address_ar",
  "google_maps_url",
  "currency",
  "currency_ar",
  "instagram_url",
  "facebook_url",
] as const;

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const all = url.searchParams.get("all") === "1";
  const settings = getSettings();
  if (all) {
    const { admin, res } = await requireAdmin();
    if (!admin) return res;
    return NextResponse.json(settings);
  }
  const publicSettings: Record<string, string> = {};
  for (const k of PUBLIC_KEYS) publicSettings[k] = settings[k];
  return NextResponse.json(publicSettings);
}

const Schema = z.record(z.string(), z.string());

export async function PUT(req: NextRequest) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  try {
    const body = Schema.parse(await req.json());
    const allowedKeys = new Set(Object.keys(DEFAULT_SETTINGS));
    const patch: Record<string, string> = {};
    for (const [k, v] of Object.entries(body)) {
      if (allowedKeys.has(k)) patch[k] = v;
    }
    setSettings(patch);
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof z.ZodError) return badRequest("Invalid settings payload");
    return serverError(err);
  }
}
