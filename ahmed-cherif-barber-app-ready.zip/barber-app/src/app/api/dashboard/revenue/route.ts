import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, badRequest, serverError } from "@/lib/api-helpers";

function rangeRevenue(from: string, to: string) {
  const row = db
    .prepare(
      `SELECT COALESCE(SUM(price_at_booking), 0) as revenue, COUNT(*) as count
       FROM appointments WHERE status = 'COMPLETED' AND date BETWEEN ? AND ?`
    )
    .get(from, to) as { revenue: number; count: number };
  return row;
}

export async function GET(req: NextRequest) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;

  const url = new URL(req.url);
  const from = url.searchParams.get("from");
  const to = url.searchParams.get("to");

  try {
    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);
    const weekAgo = new Date(now.getTime() - 6 * 86400000).toISOString().slice(0, 10);
    const monthStart = `${todayStr.slice(0, 7)}-01`;

    if (from && to) {
      const custom = rangeRevenue(from, to);
      return NextResponse.json({ custom });
    }

    const today = rangeRevenue(todayStr, todayStr);
    const week = rangeRevenue(weekAgo, todayStr);
    const month = rangeRevenue(monthStart, todayStr);

    // last 14 days series for a simple chart
    const series = db
      .prepare(
        `SELECT date, COALESCE(SUM(price_at_booking), 0) as revenue
         FROM appointments
         WHERE status = 'COMPLETED' AND date >= date('now', '-13 days')
         GROUP BY date ORDER BY date ASC`
      )
      .all();

    return NextResponse.json({ today, week, month, series });
  } catch (err) {
    return serverError(err);
  }
}
