import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, serverError } from "@/lib/api-helpers";

export async function GET() {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  try {
    const today = new Date().toISOString().slice(0, 10);
    const row = db
      .prepare(
        `SELECT
           COUNT(*) as total,
           SUM(CASE WHEN status = 'CONFIRMED' THEN 1 ELSE 0 END) as confirmed,
           SUM(CASE WHEN status = 'COMPLETED' THEN 1 ELSE 0 END) as completed,
           SUM(CASE WHEN status = 'CANCELLED' THEN 1 ELSE 0 END) as cancelled,
           SUM(CASE WHEN status = 'NO_SHOW' THEN 1 ELSE 0 END) as no_shows,
           SUM(CASE WHEN status = 'COMPLETED' THEN price_at_booking ELSE 0 END) as revenue
         FROM appointments WHERE date = ?`
      )
      .get(today);
    const upcoming = db
      .prepare(
        `SELECT a.*, c.name as customer_name, c.phone as customer_phone FROM appointments a
         JOIN customers c ON c.id = a.customer_id
         WHERE a.date = ? AND a.status = 'CONFIRMED' ORDER BY a.start_time ASC`
      )
      .all(today);
    const totalCustomers = db.prepare("SELECT COUNT(*) as n FROM customers").get() as { n: number };
    return NextResponse.json({ today, ...row, upcomingToday: upcoming, totalCustomers: totalCustomers.n });
  } catch (err) {
    return serverError(err);
  }
}
