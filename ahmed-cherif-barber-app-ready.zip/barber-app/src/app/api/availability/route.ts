import { NextRequest, NextResponse } from "next/server";
import { getSlotsForDate } from "@/lib/availability";
import { badRequest, serverError } from "@/lib/api-helpers";
import { isShopOpen } from "@/lib/settings";

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const date = url.searchParams.get("date");
  const serviceId = Number(url.searchParams.get("serviceId"));

  if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return badRequest("Invalid date");
  if (!serviceId) return badRequest("Invalid serviceId");

  try {
    const slots = getSlotsForDate(date, serviceId);
    return NextResponse.json({ slots, shopOpen: isShopOpen() });
  } catch (err) {
    return serverError(err);
  }
}
