import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentAdmin, hashPassword, verifyPassword } from "@/lib/auth";
import { badRequest, serverError } from "@/lib/api-helpers";
import { z } from "zod";

const Schema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z
    .string()
    .min(10, "Password must be at least 10 characters")
    .regex(/[A-Za-z]/, "Password must contain a letter")
    .regex(/[0-9]/, "Password must contain a number"),
  newEmail: z.string().email().optional(),
});

export async function POST(req: NextRequest) {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  try {
    const body = Schema.parse(await req.json());
    const ok = await verifyPassword(body.currentPassword, admin.password_hash);
    if (!ok) return NextResponse.json({ error: "wrong_current_password" }, { status: 403 });

    const hash = await hashPassword(body.newPassword);
    if (body.newEmail && body.newEmail !== admin.email) {
      const taken = db.prepare("SELECT id FROM admins WHERE email = ? AND id != ?").get(body.newEmail, admin.id);
      if (taken) return NextResponse.json({ error: "email_taken" }, { status: 409 });
      db.prepare("UPDATE admins SET password_hash = ?, email = ? WHERE id = ?").run(hash, body.newEmail, admin.id);
    } else {
      db.prepare("UPDATE admins SET password_hash = ? WHERE id = ?").run(hash, admin.id);
    }
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof z.ZodError) return badRequest(err.issues.map((i) => i.message).join(", "));
    return serverError(err);
  }
}
