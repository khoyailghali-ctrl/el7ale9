import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { verifyPassword, signSession, setSessionCookie, type AdminRow } from "@/lib/auth";
import { badRequest, serverError } from "@/lib/api-helpers";
import { z } from "zod";

const Schema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

// naive login rate-limit to blunt brute force on the demo credentials
const attempts = new Map<string, { count: number; resetAt: number }>();
function limited(key: string) {
  const now = Date.now();
  const e = attempts.get(key);
  if (!e || now > e.resetAt) {
    attempts.set(key, { count: 1, resetAt: now + 5 * 60_000 });
    return false;
  }
  e.count += 1;
  return e.count > 8;
}

export async function POST(req: NextRequest) {
  try {
    const body = Schema.parse(await req.json());
    const ip = req.headers.get("x-forwarded-for") || "local";
    if (limited(`${ip}:${body.email}`)) {
      return NextResponse.json({ error: "too_many_attempts" }, { status: 429 });
    }

    const admin = db.prepare("SELECT * FROM admins WHERE email = ?").get(body.email) as
      | AdminRow
      | undefined;
    if (!admin) return NextResponse.json({ error: "invalid_credentials" }, { status: 401 });

    const valid = await verifyPassword(body.password, admin.password_hash);
    if (!valid) return NextResponse.json({ error: "invalid_credentials" }, { status: 401 });

    const token = signSession(admin.id);
    await setSessionCookie(token);
    return NextResponse.json({ ok: true, admin: { id: admin.id, email: admin.email, name: admin.name } });
  } catch (err) {
    if (err instanceof z.ZodError) return badRequest("Invalid credentials format");
    return serverError(err);
  }
}
