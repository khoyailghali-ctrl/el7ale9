import { NextRequest, NextResponse } from "next/server";
import { isShopOpen, setSettings } from "@/lib/settings";
import { requireAdmin, badRequest, serverError } from "@/lib/api-helpers";
import { z } from "zod";

export async function GET() {
  return NextResponse.json({ open: isShopOpen() });
}

const Schema = z.object({ open: z.boolean() });

export async function PATCH(req: NextRequest) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  try {
    const body = Schema.parse(await req.json());
    setSettings({ shop_open: body.open ? "1" : "0" });
    return NextResponse.json({ ok: true, open: body.open });
  } catch (err) {
    if (err instanceof z.ZodError) return badRequest("Invalid payload");
    return serverError(err);
  }
}
