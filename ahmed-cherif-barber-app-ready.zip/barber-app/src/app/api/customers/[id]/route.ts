import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, serverError } from "@/lib/api-helpers";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  const { id } = await ctx.params;
  try {
    const customer = db.prepare("SELECT * FROM customers WHERE id = ?").get(id);
    if (!customer) return NextResponse.json({ error: "not_found" }, { status: 404 });
    const appointments = db
      .prepare("SELECT * FROM appointments WHERE customer_id = ? ORDER BY date DESC, start_time DESC")
      .all(id);
    return NextResponse.json({ customer, appointments });
  } catch (err) {
    return serverError(err);
  }
}
