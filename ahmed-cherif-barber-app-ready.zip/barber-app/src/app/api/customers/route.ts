import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin, serverError } from "@/lib/api-helpers";

export async function GET() {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  try {
    const rows = db
      .prepare(
        `SELECT
           c.id, c.name, c.phone, c.created_at,
           COUNT(a.id) as total_appointments,
           SUM(CASE WHEN a.status = 'COMPLETED' THEN 1 ELSE 0 END) as completed,
           SUM(CASE WHEN a.status = 'CANCELLED' THEN 1 ELSE 0 END) as cancelled,
           SUM(CASE WHEN a.status = 'NO_SHOW' THEN 1 ELSE 0 END) as no_shows,
           SUM(CASE WHEN a.status = 'COMPLETED' THEN a.price_at_booking ELSE 0 END) as total_spent,
           MAX(CASE WHEN a.status != 'CANCELLED' AND a.date <= date('now') THEN a.date END) as last_appointment,
           MIN(CASE WHEN a.status = 'CONFIRMED' AND a.date >= date('now') THEN a.date END) as next_appointment
         FROM customers c
         LEFT JOIN appointments a ON a.customer_id = c.id
         GROUP BY c.id
         ORDER BY c.created_at DESC`
      )
      .all();
    return NextResponse.json(rows);
  } catch (err) {
    return serverError(err);
  }
}
