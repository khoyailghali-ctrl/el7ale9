import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getAllBusinessHours } from "@/lib/availability";
import { requireAdmin, badRequest, serverError } from "@/lib/api-helpers";
import { z } from "zod";

export async function GET() {
  return NextResponse.json(getAllBusinessHours());
}

const PeriodSchema = z.object({ start: z.string().regex(/^\d{2}:\d{2}$/), end: z.string().regex(/^\d{2}:\d{2}$/) });
const DaySchema = z.object({
  day_of_week: z.number().int().min(0).max(6),
  is_open: z.boolean(),
  periods: z.array(PeriodSchema),
});
const Schema = z.object({ days: z.array(DaySchema) });

export async function PUT(req: NextRequest) {
  const { admin, res } = await requireAdmin();
  if (!admin) return res;
  try {
    const body = Schema.parse(await req.json());
    const stmt = db.prepare(
      `INSERT INTO business_hours (day_of_week, is_open, periods) VALUES (?, ?, ?)
       ON CONFLICT(day_of_week) DO UPDATE SET is_open = excluded.is_open, periods = excluded.periods`
    );
    for (const d of body.days) {
      stmt.run(d.day_of_week, d.is_open ? 1 : 0, JSON.stringify(d.periods));
    }
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof z.ZodError) return badRequest(err.issues.map((i) => i.message).join(", "));
    return serverError(err);
  }
}
