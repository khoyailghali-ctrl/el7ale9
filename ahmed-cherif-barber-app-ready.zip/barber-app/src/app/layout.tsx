import type { Metadata } from "next";
import "./globals.css";
import { LanguageProvider } from "@/components/LanguageProvider";
import { ToastProvider } from "@/components/Toast";

// NOTE: this sandbox cannot reach fonts.googleapis.com, so next/font/google
// would silently fall back to system fonts anyway on every build here. The
// font stack below is defined directly in globals.css instead — swap in
// next/font/google (Fraunces / Inter / Cairo, as originally set up) once
// you're building somewhere with normal internet access; see README.

export const metadata: Metadata = {
  title: "الحلاق أحمد الشريف | Ahmed Cherif Barber",
  description: "Style. Precision. Confidence. Book your appointment at Ahmed Cherif, Sfax.",
  icons: {
    icon: "/logo.png",
    apple: "/logo.png",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className="h-full antialiased">
      <body className="min-h-full flex flex-col" style={{ background: "var(--paper)" }}>
        <LanguageProvider>
          <ToastProvider>{children}</ToastProvider>
        </LanguageProvider>
      </body>
    </html>
  );
}
