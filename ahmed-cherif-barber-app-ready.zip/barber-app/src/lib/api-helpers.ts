import { NextResponse } from "next/server";
import { getCurrentAdmin } from "./auth";

export async function requireAdmin() {
  const admin = await getCurrentAdmin();
  if (!admin) {
    return { admin: null, res: NextResponse.json({ error: "Unauthorized" }, { status: 401 }) };
  }
  return { admin, res: null };
}

export function badRequest(message: string) {
  return NextResponse.json({ error: message }, { status: 400 });
}

export function serverError(err: unknown) {
  // eslint-disable-next-line no-console
  console.error(err);
  return NextResponse.json({ error: "Internal server error" }, { status: 500 });
}
