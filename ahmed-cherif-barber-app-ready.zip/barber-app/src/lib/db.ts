import { DatabaseSync } from "node:sqlite";
import path from "node:path";
import fs from "node:fs";
import bcrypt from "bcryptjs";

// NOTE ON DATABASE CHOICE
// -----------------------
// The spec calls for PostgreSQL. This build sandbox has no network access to
// a Postgres server (or to Prisma's binary CDN), so we use Node's built-in
// `node:sqlite` module instead: a real, file-backed, transactional SQL
// database (not an in-memory mock, not localStorage). All queries here are
// plain parameterized SQL, so porting to Postgres later is a matter of
// swapping this file's driver for `pg` and adjusting the few SQLite-specific
// pragmas below — the schema and query logic are already standard SQL.
// See README.md > "Moving to PostgreSQL" for the exact steps.

const DB_PATH = process.env.DATABASE_PATH || path.join(process.cwd(), "data", "app.db");

declare global {
  // eslint-disable-next-line no-var
  var __barberDb: DatabaseSync | undefined;
}

function createConnection(): DatabaseSync {
  // Only runs when the running site first needs the database, never while
  // the site is being built (the hosting volume does not exist at build time).
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  const conn = new DatabaseSync(DB_PATH);
  conn.exec("PRAGMA busy_timeout = 5000;");
  conn.exec("PRAGMA journal_mode = WAL;");
  conn.exec("PRAGMA foreign_keys = ON;");
  runMigrations(conn);
  runBootstrap(conn);
  return conn;
}

let connection: DatabaseSync | undefined = global.__barberDb;

function getDb(): DatabaseSync {
  if (!connection) {
    connection = createConnection();
    if (process.env.NODE_ENV !== "production") global.__barberDb = connection;
  }
  return connection;
}

// Lazy handle: importing this file does NOT touch the database. The first
// real query opens it, creates the tables and the first-run defaults.
export const db: DatabaseSync = new Proxy({} as DatabaseSync, {
  get(_target, prop) {
    const real = getDb() as unknown as Record<string | symbol, unknown>;
    const value = real[prop];
    return typeof value === "function" ? (value as (...a: unknown[]) => unknown).bind(real) : value;
  },
});

function runMigrations(db: DatabaseSync) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      name TEXT NOT NULL DEFAULT 'Admin',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS customers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_customers_phone ON customers(phone);

    CREATE TABLE IF NOT EXISTS services (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name_en TEXT NOT NULL,
      name_ar TEXT NOT NULL,
      description_en TEXT NOT NULL DEFAULT '',
      description_ar TEXT NOT NULL DEFAULT '',
      price REAL NOT NULL,
      duration_minutes INTEGER NOT NULL,
      active INTEGER NOT NULL DEFAULT 1,
      sort_order INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    -- One row per weekday (0=Sunday .. 6=Saturday). periods is a JSON array
    -- of start/end 24h HH:MM strings, allowing split shifts / breaks.
    CREATE TABLE IF NOT EXISTS business_hours (
      day_of_week INTEGER PRIMARY KEY,
      is_open INTEGER NOT NULL DEFAULT 1,
      periods TEXT NOT NULL DEFAULT '[]'
    );

    -- Full-day or partial-time closures / exceptions on specific dates.
    CREATE TABLE IF NOT EXISTS closures (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      full_day INTEGER NOT NULL DEFAULT 1,
      start_time TEXT,
      end_time TEXT,
      reason TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_closures_date ON closures(date);

    CREATE TABLE IF NOT EXISTS announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title_en TEXT NOT NULL,
      title_ar TEXT NOT NULL,
      message_en TEXT NOT NULL,
      message_ar TEXT NOT NULL,
      start_date TEXT NOT NULL,
      end_date TEXT NOT NULL,
      active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS appointments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_id INTEGER NOT NULL REFERENCES customers(id),
      service_id INTEGER NOT NULL REFERENCES services(id),
      date TEXT NOT NULL,
      start_time TEXT NOT NULL,
      end_time TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'CONFIRMED',
      price_at_booking REAL NOT NULL,
      service_name_en TEXT NOT NULL,
      service_name_ar TEXT NOT NULL,
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX IF NOT EXISTS idx_appt_date ON appointments(date);
    CREATE INDEX IF NOT EXISTS idx_appt_customer ON appointments(customer_id);
    CREATE INDEX IF NOT EXISTS idx_appt_status ON appointments(status);

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS notifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      audience TEXT NOT NULL, -- 'ADMIN'
      type TEXT NOT NULL,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      read INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
}


// Non-destructive first-run bootstrap: only inserts rows when a table is
// empty, so it is safe on a live database and never overwrites real data.
function runBootstrap(db: DatabaseSync) {
  const count = (t: string) =>
    (db.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get() as { n: number }).n;

  if (count("admins") === 0) {
    const email = process.env.ADMIN_EMAIL || (process.env.NODE_ENV !== "production" ? "admin@ahmedcherif.tn" : "");
    const password = process.env.ADMIN_PASSWORD || (process.env.NODE_ENV !== "production" ? "Ahmed@12345" : "");
    if (email && password) {
      db.prepare("INSERT INTO admins (email, password_hash, name) VALUES (?, ?, ?)").run(
        email,
        bcrypt.hashSync(password, 10),
        "Ahmed Cherif"
      );
    } else {
      // eslint-disable-next-line no-console
      console.warn("[bootstrap] No admin exists. Set ADMIN_EMAIL and ADMIN_PASSWORD, then restart.");
    }
  }

  if (count("business_hours") === 0) {
    const standard = JSON.stringify([
      { start: "10:00", end: "14:00" },
      { start: "15:00", end: "21:00" },
    ]);
    const ins = db.prepare("INSERT INTO business_hours (day_of_week, is_open, periods) VALUES (?, ?, ?)");
    for (let d = 0; d <= 6; d++) ins.run(d, d === 5 ? 0 : 1, d === 5 ? "[]" : standard);
  }

  if (count("services") === 0) {
    const ins = db.prepare(
      `INSERT INTO services (name_en, name_ar, description_en, description_ar, price, duration_minutes, active, sort_order)
       VALUES (?, ?, '', '', ?, ?, 1, ?)`
    );
    [
      ["Classic Haircut", "قصة كلاسيكية", 15, 45],
      ["Haircut + Beard", "قصة ولحية", 25, 60],
      ["Beard Trim", "تهذيب اللحية", 10, 30],
      ["Fade Haircut", "قصة فايد", 18, 45],
      ["Kids Haircut", "قصة أطفال", 12, 30],
    ].forEach(([en, ar, price, dur], i) => ins.run(en as string, ar as string, price as number, dur as number, i));
  }
}


// Used by the seed script to make sure tables exist.
export function migrate() {
  getDb();
}

export function nowIso() {
  return new Date().toISOString();
}
