import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { cookies } from "next/headers";
import { db } from "./db";

const SESSION_COOKIE = "admin_session";
const SECRET = process.env.AUTH_SECRET || "dev-only-insecure-secret-change-me";

if (process.env.NODE_ENV === "production" && !process.env.AUTH_SECRET) {
  // eslint-disable-next-line no-console
  console.warn(
    "[auth] AUTH_SECRET is not set. Set a strong random secret in production (see .env.example)."
  );
}

export interface AdminRow {
  id: number;
  email: string;
  password_hash: string;
  name: string;
}

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, 10);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}

export function signSession(adminId: number): string {
  return jwt.sign({ sub: adminId }, SECRET, { expiresIn: "7d" });
}

export function verifySession(token: string): { sub: number } | null {
  try {
    return jwt.verify(token, SECRET) as unknown as { sub: number };
  } catch {
    return null;
  }
}

export async function setSessionCookie(token: string) {
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function clearSessionCookie() {
  const store = await cookies();
  store.delete(SESSION_COOKIE);
}

export async function getCurrentAdmin(): Promise<AdminRow | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const payload = verifySession(token);
  if (!payload) return null;
  const admin = db
    .prepare("SELECT id, email, password_hash, name FROM admins WHERE id = ?")
    .get(payload.sub) as AdminRow | undefined;
  return admin ?? null;
}

export { SESSION_COOKIE };
