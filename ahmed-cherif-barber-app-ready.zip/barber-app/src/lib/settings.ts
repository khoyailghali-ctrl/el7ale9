import { db } from "./db";

export const DEFAULT_SETTINGS = {
  business_name_en: "Ahmed Cherif",
  business_name_ar: "الحلاق أحمد الشريف",
  tagline_en: "Style. Precision. Confidence.",
  tagline_ar: "أناقة. دقة. ثقة.",
  phone: "+216 22 000 111",
  address_en: "Route El Ain, Sfax, KM 4, Tunisia",
  address_ar: "طريق العين، صفاقس، كم 4، تونس",
  google_maps_url: "https://maps.google.com/?q=Route+El+Ain+Sfax+Tunisia",
  currency: "TND",
  currency_ar: "د.ت",
  timezone: "Africa/Tunis",
  cancellation_window_hours: "2",
  slot_interval_minutes: "15",
  shop_open: "1",
  instagram_url: "",
  facebook_url: "",
};

export type SettingsMap = typeof DEFAULT_SETTINGS;

export function getSettings(): SettingsMap {
  const rows = db.prepare("SELECT key, value FROM settings").all() as {
    key: string;
    value: string;
  }[];
  const map: Record<string, string> = { ...DEFAULT_SETTINGS };
  for (const r of rows) map[r.key] = r.value;
  return map as SettingsMap;
}

export function getSetting(key: keyof SettingsMap): string {
  const row = db.prepare("SELECT value FROM settings WHERE key = ?").get(key) as
    | { value: string }
    | undefined;
  return row?.value ?? DEFAULT_SETTINGS[key];
}

export function setSettings(patch: Partial<SettingsMap>) {
  const stmt = db.prepare(
    "INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value"
  );
  for (const [key, value] of Object.entries(patch)) {
    stmt.run(key, String(value));
  }
}

export function isShopOpen(): boolean {
  return getSetting("shop_open") === "1";
}
