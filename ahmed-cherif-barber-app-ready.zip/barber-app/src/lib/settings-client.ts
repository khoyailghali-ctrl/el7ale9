export interface PublicSettings {
  business_name_en: string;
  business_name_ar: string;
  tagline_en: string;
  tagline_ar: string;
  phone: string;
  address_en: string;
  address_ar: string;
  google_maps_url: string;
  currency: string;
  currency_ar: string;
  instagram_url: string;
  facebook_url: string;
}
