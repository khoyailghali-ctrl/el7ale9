export type AppointmentStatus = "CONFIRMED" | "COMPLETED" | "CANCELLED" | "NO_SHOW";

export interface Service {
  id: number;
  name_en: string;
  name_ar: string;
  description_en: string;
  description_ar: string;
  price: number;
  duration_minutes: number;
  active: number;
  sort_order: number;
}

export interface Customer {
  id: number;
  name: string;
  phone: string;
  created_at: string;
}

export interface Appointment {
  id: number;
  customer_id: number;
  service_id: number;
  date: string; // YYYY-MM-DD
  start_time: string; // HH:MM
  end_time: string; // HH:MM
  status: AppointmentStatus;
  price_at_booking: number;
  service_name_en: string;
  service_name_ar: string;
  notes: string;
  created_at: string;
  updated_at: string;
}

export interface AppointmentWithCustomer extends Appointment {
  customer_name: string;
  customer_phone: string;
}

export interface Period {
  start: string; // HH:MM
  end: string; // HH:MM
}

export interface BusinessHoursDay {
  day_of_week: number;
  is_open: number;
  periods: Period[];
}

export interface Closure {
  id: number;
  date: string;
  full_day: number;
  start_time: string | null;
  end_time: string | null;
  reason: string;
}

export interface Announcement {
  id: number;
  title_en: string;
  title_ar: string;
  message_en: string;
  message_ar: string;
  start_date: string;
  end_date: string;
  active: number;
}

export interface SlotInfo {
  time: string; // HH:MM
  status: "available" | "booked" | "closed";
}

export type Lang = "en" | "ar";
