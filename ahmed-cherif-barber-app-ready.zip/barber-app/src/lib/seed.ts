import { db, migrate } from "./db";
import { hashPassword } from "./auth";
import { setSettings } from "./settings";

async function seed() {
  migrate();

  // --- wipe demo tables (idempotent re-seed) ---
  db.exec(`
    DELETE FROM appointments;
    DELETE FROM customers;
    DELETE FROM services;
    DELETE FROM business_hours;
    DELETE FROM closures;
    DELETE FROM announcements;
    DELETE FROM admins;
    DELETE FROM notifications;
  `);

  // --- admin ---
  const passwordHash = await hashPassword("Ahmed@12345");
  db.prepare(
    "INSERT INTO admins (email, password_hash, name) VALUES (?, ?, ?)"
  ).run("admin@ahmedcherif.tn", passwordHash, "Ahmed Cherif");

  // --- settings ---
  setSettings({ shop_open: "1" });

  // --- business hours: Sat-Thu 10:00-14:00 & 15:00-21:00, Friday off ---
  // day_of_week: 0=Sun .. 6=Sat
  const standard = JSON.stringify([
    { start: "10:00", end: "14:00" },
    { start: "15:00", end: "21:00" },
  ]);
  const insertHours = db.prepare(
    "INSERT INTO business_hours (day_of_week, is_open, periods) VALUES (?, ?, ?)"
  );
  for (let dow = 0; dow <= 6; dow++) {
    const isFriday = dow === 5;
    insertHours.run(dow, isFriday ? 0 : 1, isFriday ? "[]" : standard);
  }

  // --- services ---
  const services = [
    ["Classic Haircut", "قصة كلاسيكية", 15, 45],
    ["Haircut + Beard", "قصة ولحية", 25, 60],
    ["Beard Trim", "تهذيب اللحية", 10, 30],
    ["Fade Haircut", "قصة فايد", 18, 45],
    ["Kids Haircut", "قصة أطفال", 12, 30],
  ] as const;
  const insertService = db.prepare(
    `INSERT INTO services (name_en, name_ar, description_en, description_ar, price, duration_minutes, active, sort_order)
     VALUES (?, ?, ?, ?, ?, ?, 1, ?)`
  );
  services.forEach(([en, ar, price, duration], i) => {
    insertService.run(en, ar, "", "", price, duration, i);
  });

  // --- demo customers ---
  const customers = [
    ["Mohamed Ben Ali", "22123456"],
    ["Yassine Trabelsi", "55234567"],
    ["Ahmed Mansour", "98345678"],
    ["Sami Gharbi", "27456789"],
  ];
  const insertCustomer = db.prepare(
    "INSERT INTO customers (name, phone) VALUES (?, ?)"
  );
  const customerIds: number[] = [];
  for (const [name, phone] of customers) {
    const info = insertCustomer.run(name, phone);
    customerIds.push(Number(info.lastInsertRowid));
  }

  // --- demo announcement ---
  db.prepare(
    `INSERT INTO announcements (title_en, title_ar, message_en, message_ar, start_date, end_date, active)
     VALUES (?, ?, ?, ?, ?, ?, 1)`
  ).run(
    "Welcome",
    "أهلاً بكم",
    "Welcome to our new online booking system!",
    "مرحبًا بكم في نظام الحجز الإلكتروني الجديد!",
    "2026-01-01",
    "2026-12-31"
  );

  // --- demo appointments spread across a few days ---
  const svcRows = db.prepare("SELECT id, name_en, name_ar, price FROM services").all() as {
    id: number;
    name_en: string;
    name_ar: string;
    price: number;
  }[];

  const today = new Date();
  const fmt = (d: Date) => d.toISOString().slice(0, 10);

  const insertAppt = db.prepare(
    `INSERT INTO appointments
      (customer_id, service_id, date, start_time, end_time, status, price_at_booking, service_name_en, service_name_ar)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  );

  const demo: Array<[number, number, number, string, string, string]> = [
    // dayOffset, customerIdx, serviceIdx, start, end, status
    [0, 0, 0, "10:00", "10:45", "COMPLETED"] as any,
  ];

  const plan: Array<{
    dayOffset: number;
    customerIdx: number;
    serviceIdx: number;
    start: string;
    status: string;
  }> = [
    { dayOffset: 0, customerIdx: 0, serviceIdx: 0, start: "10:00", status: "COMPLETED" },
    { dayOffset: 0, customerIdx: 1, serviceIdx: 1, start: "11:00", status: "COMPLETED" },
    { dayOffset: 0, customerIdx: 2, serviceIdx: 3, start: "16:30", status: "CONFIRMED" },
    { dayOffset: 0, customerIdx: 3, serviceIdx: 2, start: "17:30", status: "CONFIRMED" },
    { dayOffset: -1, customerIdx: 0, serviceIdx: 1, start: "12:00", status: "COMPLETED" },
    { dayOffset: -1, customerIdx: 1, serviceIdx: 0, start: "18:00", status: "NO_SHOW" },
    { dayOffset: -2, customerIdx: 2, serviceIdx: 4, start: "10:30", status: "COMPLETED" },
    { dayOffset: -3, customerIdx: 3, serviceIdx: 1, start: "15:30", status: "CANCELLED" },
    { dayOffset: 1, customerIdx: 0, serviceIdx: 3, start: "19:00", status: "CONFIRMED" },
    { dayOffset: 2, customerIdx: 1, serviceIdx: 2, start: "10:15", status: "CONFIRMED" },
  ];

  for (const p of plan) {
    const svc = svcRows[p.serviceIdx];
    const service = db
      .prepare("SELECT duration_minutes FROM services WHERE id = ?")
      .get(svc.id) as { duration_minutes: number };
    const [h, m] = p.start.split(":").map(Number);
    const startMin = h * 60 + m;
    const endMin = startMin + service.duration_minutes;
    const end = `${String(Math.floor(endMin / 60)).padStart(2, "0")}:${String(
      endMin % 60
    ).padStart(2, "0")}`;
    const date = fmt(new Date(today.getTime() + p.dayOffset * 86400000));
    insertAppt.run(
      customerIds[p.customerIdx],
      svc.id,
      date,
      p.start,
      end,
      p.status,
      svc.price,
      svc.name_en,
      svc.name_ar
    );
  }

  console.log("Seed complete.");
  console.log("Admin login: admin@ahmedcherif.tn / Ahmed@12345");
}

seed().catch((e) => {
  console.error(e);
  process.exit(1);
});
