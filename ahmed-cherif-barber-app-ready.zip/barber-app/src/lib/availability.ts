import { db } from "./db";
import { getSetting, isShopOpen } from "./settings";
import type { BusinessHoursDay, Closure, Period, Service, SlotInfo } from "./types";

// ---- time helpers (all times are "HH:MM" 24h strings, business-local) ----

export function toMinutes(t: string): number {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}

export function toHHMM(mins: number): string {
  const h = Math.floor(mins / 60)
    .toString()
    .padStart(2, "0");
  const m = (mins % 60).toString().padStart(2, "0");
  return `${h}:${m}`;
}

function rangesOverlap(aStart: number, aEnd: number, bStart: number, bEnd: number): boolean {
  return aStart < bEnd && bStart < aEnd;
}

export function getBusinessHoursForDay(dayOfWeek: number): BusinessHoursDay {
  const row = db
    .prepare("SELECT day_of_week, is_open, periods FROM business_hours WHERE day_of_week = ?")
    .get(dayOfWeek) as { day_of_week: number; is_open: number; periods: string } | undefined;
  if (!row) return { day_of_week: dayOfWeek, is_open: 0, periods: [] };
  return { day_of_week: row.day_of_week, is_open: row.is_open, periods: JSON.parse(row.periods) };
}

export function getAllBusinessHours(): BusinessHoursDay[] {
  const rows = db
    .prepare("SELECT day_of_week, is_open, periods FROM business_hours ORDER BY day_of_week")
    .all() as { day_of_week: number; is_open: number; periods: string }[];
  return rows.map((r) => ({ ...r, periods: JSON.parse(r.periods) as Period[] }));
}

export function getClosuresForDate(date: string): Closure[] {
  return db.prepare("SELECT * FROM closures WHERE date = ?").all(date) as unknown as Closure[];
}

export function getService(serviceId: number): Service | undefined {
  return db.prepare("SELECT * FROM services WHERE id = ?").get(serviceId) as Service | undefined;
}

/**
 * Returns the open periods for a date, in minutes-from-midnight, after
 * subtracting any closures registered for that date. Returns [] if the shop
 * is closed that day (weekly schedule) or fully closed by a closure.
 */
function getOpenWindowsMinutes(date: string): Array<[number, number]> {
  const dow = new Date(date + "T00:00:00").getDay();
  const hours = getBusinessHoursForDay(dow);
  if (!hours.is_open || hours.periods.length === 0) return [];

  let windows: Array<[number, number]> = hours.periods.map((p) => [
    toMinutes(p.start),
    toMinutes(p.end),
  ]);

  const closures = getClosuresForDate(date);
  for (const c of closures) {
    if (c.full_day) return [];
    if (!c.start_time || !c.end_time) continue;
    const cs = toMinutes(c.start_time);
    const ce = toMinutes(c.end_time);
    // subtract [cs, ce) from every window, possibly splitting a window in two
    const next: Array<[number, number]> = [];
    for (const [ws, we] of windows) {
      if (!rangesOverlap(ws, we, cs, ce)) {
        next.push([ws, we]);
        continue;
      }
      if (cs > ws) next.push([ws, Math.min(cs, we)]);
      if (ce < we) next.push([Math.max(ce, ws), we]);
    }
    windows = next.filter(([s, e]) => e > s);
  }

  return windows;
}

function getBookedRangesMinutes(date: string, excludeAppointmentId?: number): Array<[number, number]> {
  const rows = db
    .prepare(
      `SELECT id, start_time, end_time FROM appointments
       WHERE date = ? AND status = 'CONFIRMED'`
    )
    .all(date) as { id: number; start_time: string; end_time: string }[];
  return rows
    .filter((r) => r.id !== excludeAppointmentId)
    .map((r) => [toMinutes(r.start_time), toMinutes(r.end_time)] as [number, number]);
}

/**
 * Generates the full slot grid for a date + service, marking each slot as
 * available / booked / closed. This is what customers see (green/red/gray).
 */
export function getSlotsForDate(date: string, serviceId: number): SlotInfo[] {
  const service = getService(serviceId);
  if (!service) return [];

  const interval = Number(getSetting("slot_interval_minutes")) || 15;
  const duration = service.duration_minutes;
  const windows = getOpenWindowsMinutes(date);
  const booked = getBookedRangesMinutes(date);

  // Full grid across the day's earliest-to-latest span so closed slots (e.g.
  // during a break) are also represented, not just silently missing.
  const dow = new Date(date + "T00:00:00").getDay();
  const hours = getBusinessHoursForDay(dow);
  if (!hours.is_open || hours.periods.length === 0) return [];

  const dayStart = Math.min(...hours.periods.map((p) => toMinutes(p.start)));
  const dayEnd = Math.max(...hours.periods.map((p) => toMinutes(p.end)));

  const isPastCutoff = (startMin: number) => {
    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);
    if (date !== todayStr) return false;
    const nowMin = now.getHours() * 60 + now.getMinutes();
    return startMin <= nowMin;
  };

  const slots: SlotInfo[] = [];
  for (let t = dayStart; t + duration <= dayEnd; t += interval) {
    const slotEnd = t + duration;
    const fitsInOpenWindow = windows.some(([ws, we]) => t >= ws && slotEnd <= we);
    const conflictsBooking = booked.some(([bs, be]) => rangesOverlap(t, slotEnd, bs, be));

    let status: SlotInfo["status"];
    if (isPastCutoff(t)) status = "closed";
    else if (!fitsInOpenWindow) status = "closed";
    else if (conflictsBooking) status = "booked";
    else status = "available";

    slots.push({ time: toHHMM(t), status });
  }
  return slots;
}

export type BookingResult =
  | { ok: true; appointmentId: number }
  | { ok: false; reason: "SHOP_CLOSED" | "SLOT_TAKEN" | "INVALID_SLOT" | "SERVICE_NOT_FOUND" };

/**
 * Atomically validates and reserves a slot. Runs inside a SQLite transaction
 * so a re-check of conflicting appointments and the insert happen as one
 * unit — this is the server-side guarantee against double booking. Because
 * this Node process is single-threaded and node:sqlite executes
 * synchronously, no other request can interleave between the check and the
 * insert within this function.
 */
export function bookAppointment(params: {
  serviceId: number;
  date: string;
  startTime: string;
  customerId: number;
  bypassShopOpenCheck?: boolean;
}): BookingResult {
  const { serviceId, date, startTime, customerId, bypassShopOpenCheck } = params;

  if (!bypassShopOpenCheck && !isShopOpen()) return { ok: false, reason: "SHOP_CLOSED" };

  const service = getService(serviceId);
  if (!service || !service.active) return { ok: false, reason: "SERVICE_NOT_FOUND" };

  const startMin = toMinutes(startTime);
  const endMin = startMin + service.duration_minutes;
  const endTime = toHHMM(endMin);

  const windows = getOpenWindowsMinutes(date);
  const fits = windows.some(([ws, we]) => startMin >= ws && endMin <= we);
  if (!fits) return { ok: false, reason: "INVALID_SLOT" };

  db.exec("BEGIN IMMEDIATE");
  try {
    const conflict = db
      .prepare(
        `SELECT id FROM appointments
         WHERE date = ? AND status = 'CONFIRMED'
           AND start_time < ? AND end_time > ?`
      )
      .get(date, endTime, startTime);

    if (conflict) {
      db.exec("ROLLBACK");
      return { ok: false, reason: "SLOT_TAKEN" };
    }

    const info = db
      .prepare(
        `INSERT INTO appointments
          (customer_id, service_id, date, start_time, end_time, status, price_at_booking, service_name_en, service_name_ar)
         VALUES (?, ?, ?, ?, ?, 'CONFIRMED', ?, ?, ?)`
      )
      .run(
        customerId,
        serviceId,
        date,
        startTime,
        endTime,
        service.price,
        service.name_en,
        service.name_ar
      );

    db.prepare(
      `INSERT INTO notifications (audience, type, title, body) VALUES ('ADMIN', 'NEW_APPOINTMENT', ?, ?)`
    ).run(
      "New appointment",
      `${service.name_en} on ${date} at ${startTime}`
    );

    db.exec("COMMIT");
    return { ok: true, appointmentId: Number(info.lastInsertRowid) };
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}
