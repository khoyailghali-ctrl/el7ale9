# Automatic deploy to Railway for the Ahmed Cherif barber website.
# Double-click "deploy-railway.bat" (or run this file in PowerShell).
# You only need to: log in to Railway in the browser, type an admin email,
# and type an admin password. Everything else is done for you.

$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot

function Step($msg) { Write-Host ""; Write-Host "==> $msg" -ForegroundColor Cyan }
function Fail($msg) {
  Write-Host ""; Write-Host "STOPPED: $msg" -ForegroundColor Red
  Read-Host "Press Enter to close"; exit 1
}
function Refresh-Path {
  $env:Path = [Environment]::GetEnvironmentVariable("Path","Machine") + ";" + [Environment]::GetEnvironmentVariable("Path","User")
}

Step "1/8  Checking Node.js"
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  Fail "Node.js is not installed. Install the LTS version from nodejs.org, then run this again."
}

Step "2/8  Installing the Railway tool (if needed)"
if (-not (Get-Command railway -ErrorAction SilentlyContinue)) {
  npm install -g "@railway/cli"
  Refresh-Path
}
if (-not (Get-Command railway -ErrorAction SilentlyContinue)) {
  Fail "Railway tool did not install. Close this window, open a new one, and run again."
}

Step "3/8  Log in to Railway (a browser window will open)"
railway whoami 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) {
  railway login
  railway whoami 2>$null | Out-Null
  if ($LASTEXITCODE -ne 0) { Fail "Railway login did not complete." }
}

Step "4/8  Admin account for the website"
$email = Read-Host "Admin email (Ahmed will use this to log in)"
if ($email -notmatch "^[^@\s]+@[^@\s]+\.[^@\s]+$") { Fail "That does not look like an email address." }
$sec = Read-Host "Admin password (10+ characters, letters AND numbers)" -AsSecureString
$pw = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($sec))
if ($pw.Length -lt 10 -or $pw -notmatch "[A-Za-z]" -or $pw -notmatch "[0-9]") {
  Fail "Password must be at least 10 characters with letters and numbers."
}
$bytes = New-Object byte[] 48
[Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
$secret = [Convert]::ToBase64String($bytes)

Step "5/8  Creating the Railway project and service"
railway status 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) {
  railway init --name ahmed-cherif-barber
  if ($LASTEXITCODE -ne 0) { Fail "Could not create the Railway project." }
}
railway add --service barber-app
if ($LASTEXITCODE -ne 0) {
  Write-Host "Could not add the service automatically." -ForegroundColor Yellow
  Write-Host "Run:  railway add   then choose 'Empty Service' and name it barber-app." -ForegroundColor Yellow
  Read-Host "When done, press Enter to continue"
}

Step "6/8  Saving settings (secret, admin account, database path)"
railway variable set "AUTH_SECRET=$secret" "ADMIN_EMAIL=$email" "ADMIN_PASSWORD=$pw" "DATABASE_PATH=/data/app.db"
if ($LASTEXITCODE -ne 0) {
  railway variables --set "AUTH_SECRET=$secret" --set "ADMIN_EMAIL=$email" --set "ADMIN_PASSWORD=$pw" --set "DATABASE_PATH=/data/app.db"
  if ($LASTEXITCODE -ne 0) { Fail "Could not save settings to Railway." }
}

Step "7/8  Adding permanent storage for appointments (volume at /data)"
railway volume add --mount-path /data
if ($LASTEXITCODE -ne 0) {
  Write-Host "Could not add the volume automatically." -ForegroundColor Yellow
  Write-Host "In the Railway website: your service > Settings > Volumes > add, mount path /data" -ForegroundColor Yellow
  Read-Host "When done, press Enter to continue"
}

Step "8/8  Uploading and starting the website (takes a few minutes)"
railway up --detach
if ($LASTEXITCODE -ne 0) { Fail "Upload failed. Read the message above." }
railway domain

Write-Host ""
Write-Host "DONE. Open the link above in a few minutes." -ForegroundColor Green
Write-Host "Admin page:  <your link>/admin/login   (use the email and password you just typed)"
Write-Host ""
Write-Host "To connect your own domain later, run:   railway domain yourdomain.tn"
Write-Host "Then copy the DNS record it shows into your domain seller's DNS settings."
Read-Host "Press Enter to close"
