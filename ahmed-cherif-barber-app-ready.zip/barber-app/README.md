# الحلاق أحمد الشريف — Ahmed Cherif Barber Booking System

A real, working appointment booking and management platform for Ahmed Cherif's
barber shop in Sfax, Tunisia. Bilingual (Arabic RTL / English LTR), mobile-first
customer booking, and a full admin dashboard Ahmed can run the shop from —
including from his phone.

This is genuinely functional software: a real database, real server-side
validation, real double-booking protection, real authentication. Nothing here
is a localStorage mock or a fake button.

---

## 1. Project overview

- **Public site** (`/`) — hero, about, services, opening status, gallery
  placeholders, location/map link, live announcements, contact, footer.
- **Booking flow** (`/book`) — service → date → time → info → confirm, with a
  green/booked/closed slot grid that reflects real-time availability.
- **My Appointment** (`/my-appointments`) — phone-based lookup (no account
  needed) with self-service cancellation, respecting the cancellation window.
- **Admin dashboard** (`/admin`) — today's stats, appointments list/edit,
  calendar day view, customers with computed history, services, business
  hours, closures, announcements, revenue (day/week/month + custom range),
  settings, and a one-tap shop **Open/Closed** toggle.

## 2. Requirements

- Node.js **20+** (Node 22 recommended — the app uses `node:sqlite`, which is
  stable/experimental from Node 22.5+; on Node 20 you'd need `--experimental-sqlite`).
- npm.

## 3. Installation

```bash
cd barber-app
npm install
```

## 4. Environment setup

```bash
cp .env.example .env.local
```

At minimum, set `AUTH_SECRET` to a long random string before deploying to
production:

```bash
openssl rand -base64 48
```

## 5. Database setup

No separate database server to install. The app uses SQLite via Node's
built-in `node:sqlite` — a real file-backed relational database at
`./data/app.db` (path configurable via `DATABASE_PATH`). Tables are created
automatically on first run (see `src/lib/db.ts`).

> **Why SQLite instead of the Postgres called for in the original spec?**
> This was built in a sandboxed environment with no access to a Postgres
> server or to Prisma's binary CDN. SQLite requires nothing to install and
> the schema/queries are plain SQL, so moving to Postgres later is
> straightforward — see [Moving to PostgreSQL](#moving-to-postgresql) below.

## 6. Migration

Migrations run automatically on app startup (`migrate()` in `src/lib/db.ts`
runs `CREATE TABLE IF NOT EXISTS ...` for every table). There is no separate
migration command to run.

## 7. Seed data

```bash
npm run seed
```

This creates:
- The demo admin account (see [Admin login](#13-admin-login) below)
- The 5 demo services (Classic Haircut, Haircut + Beard, Beard Trim, Fade
  Haircut, Kids Haircut)
- Standard business hours (Sat–Thu 10:00–14:00 & 15:00–21:00, Friday closed)
- 4 demo customers and a spread of demo appointments (confirmed, completed,
  cancelled, no-show) so the dashboard is immediately testable
- A welcome announcement

Re-running `npm run seed` wipes and re-seeds these tables (safe to run
repeatedly during development).

## 8. Development

```bash
npm run dev
```

Visit `http://localhost:3000`.

## 9. Production build

```bash
npm run build
npm run start
```

**Important:** because this build uses a file-based SQLite database and
in-memory rate limiting, it needs a **persistent Node.js process** (a VPS,
Docker container, Railway/Render/Fly.io-style host, etc.) — not a stateless
serverless/edge platform like Vercel's default deployment, where the
filesystem resets between invocations and multiple instances wouldn't share
one database file. If you deploy to a serverless platform, switch to Postgres
first (see below).

## 10. Deployment

1. Provision a server/container with Node 20+.
2. `npm install && npm run build`
3. Set environment variables (`AUTH_SECRET` at minimum; see `.env.example`).
4. Ensure the `data/` directory is on **persistent** storage (a mounted
   volume), not ephemeral container storage, so appointments survive restarts
   and deploys.
5. Run `npm run seed` once (or write your own seed for real business data),
   then `npm run start`.
6. Put a reverse proxy (nginx, Caddy, or your platform's built-in one) in
   front, terminating HTTPS.

### Automatic deploy on Windows (no GitHub needed)

Double-click `deploy-railway.bat`. It installs the Railway tool, opens the
browser for login, asks for the admin email and password, then creates the
project, sets the variables, adds the `/data` volume, uploads the site and
prints the public link. Domain purchase and DNS must still be done by hand.
If a step fails the script says which manual step to do instead.

To send a later change to the live site, double-click `update-railway.bat`
(it asks nothing, except to pick the project once if the folder is new).

### Deploying on Railway (step by step)

1. Push this project to a GitHub repository.
2. On railway.app: New Project > Deploy from GitHub repo > pick the repo.
3. In the service > Variables, add:
   - `AUTH_SECRET` = a long random text
   - `ADMIN_EMAIL` = the email Ahmed will log in with
   - `ADMIN_PASSWORD` = a strong password (10+ characters)
   - `DATABASE_PATH` = `/data/app.db`
4. In the service > Settings > Volumes, add a volume mounted at `/data`.
   Without it, all appointments are erased on every restart or deploy.
5. Do NOT run `npm run seed` on the live site: it deletes data. The site
   creates the admin account, default hours and 5 starter services by itself
   on first start (it only fills empty tables). Edit them in the admin.
6. Node 22+ is required; `package.json` (engines) and `.node-version`
   already ask for it.

## 11. Custom domain setup

The app reads no hardcoded domain — it's fully domain-independent. To connect
`ahmedcherif.tn` (or `.com`):

1. In your hosting provider, add the custom domain to the deployed app/service.
2. At your domain registrar, add the DNS records your host gives you —
   typically either:
   - An **A record** pointing `@` (and `www`) to your server's IP, or
   - A **CNAME record** pointing to the hostname your platform provides.
3. Wait for DNS propagation (a few minutes to a few hours).
4. Set `APP_URL` in your environment to `https://ahmedcherif.tn`.

## 12. HTTPS

Most managed hosts (Vercel, Railway, Render, Fly.io, etc.) provision a free
TLS certificate automatically once the custom domain's DNS is verified. If
self-hosting on a bare VPS, use **Caddy** (automatic HTTPS via Let's Encrypt,
zero config) or **nginx + certbot**.

The app already sets the session cookie as `secure` in production
(`src/lib/auth.ts`), so it requires HTTPS in production — don't skip this step.

## 13. Admin login

**Demo credentials (development only — created by `npm run seed`):**

- Email: `admin@ahmedcherif.tn`
- Password: `Ahmed@12345`

⚠️ Change this before going live: log in, open **Admin > Profile**, and set a
new email and password. On a live server, set `ADMIN_EMAIL` and
`ADMIN_PASSWORD` instead of using the demo account.

## 14. Demo customer data

Seeded by `npm run seed`:

| Name | Phone |
|---|---|
| Mohamed Ben Ali | 22123456 |
| Yassine Trabelsi | 55234567 |
| Ahmed Mansour | 98345678 |
| Sami Gharbi | 27456789 |

Use these to test the "My Appointment" phone lookup at `/my-appointments`.

## 15. How to change business information

Admin dashboard → **Settings**. Business name (EN/AR), tagline, phone,
address (EN/AR), Google Maps URL, cancellation window, slot interval,
currency — all editable there, no code changes needed.

## 16. How to change services

Admin dashboard → **Services**. Add, edit, deactivate. Prices and durations
are fully editable. Deactivating a service hides it from the public booking
flow without deleting its history (past appointments keep their own stored
price/name snapshot, so editing a live price never rewrites historical
revenue — see Known limitations for the one nuance here).

## 17. How to change prices

Same screen (Services → Edit). New price applies to appointments booked
**after** the change. Every appointment stores its own `price_at_booking`
snapshot at booking time, so past completed appointments and revenue reports
are never silently altered by a later price change.

## 18. How to change opening hours

Admin dashboard → **Business Hours**. Toggle each day open/closed and add one
or more time periods per day (e.g. `10:00–14:00` and `15:00–21:00` for a
midday break). For one-off exceptions (a holiday, a half-day), use
**Closures** instead — it doesn't touch the recurring weekly schedule.

## 19. How to configure announcements

Admin dashboard → **Announcements**. Set a title/message in both languages, a
start and end date, and activate it. Active announcements appear as a
dismissible banner on the public homepage.

## 20. How to configure Google Maps

Admin dashboard → **Settings** → Google Maps URL. Paste any Google Maps share
link for the shop's location; the public site's "View on Google Maps" link
uses it directly.

## 21. How to replace the logo

The logo provided (mustache mark + "CHERIF" wordmark) is currently
represented as a simple inline SVG mark (`MustacheMark` in
`src/components/Header.tsx`) rather than the original raster file, since
static assets aren't part of this generated project structure. To use the
real logo image:

1. Save the logo file as `public/logo.png` (or `.svg`).
2. In `src/components/Header.tsx` and `src/components/Footer.tsx`, replace
   `<MustacheMark />` with `<Image src="/logo.png" alt="Ahmed Cherif" width={..} height={..} />`
   (import `Image` from `next/image`).
3. For the PWA icon (if you add a manifest — see Known limitations), export
   the mark as `192x192` and `512x512` PNGs into `public/`.

## 22. How to replace shop photos

The gallery section (`src/components/HomeContent.tsx`, "GALLERY" block)
currently renders 4 placeholder tiles. Replace the placeholder `<div>` blocks
with `<Image>` components pointing at files you add to `public/gallery/`.

---

## Architecture

```
src/
  app/
    page.tsx                 Public homepage (server component)
    book/                    Booking flow route
    my-appointments/         Customer lookup/cancel route
    admin/
      login/                 Public admin login page
      (protected)/           Route group — every page here requires auth
        page.tsx              Dashboard overview
        appointments/         List, edit, create, status changes
        calendar/             Day-view calendar
        customers/            List + [id] detail with history
        services/             CRUD
        business-hours/       Weekly schedule editor
        closures/             Full-day / partial exceptions
        announcements/        CRUD
        revenue/              Day/week/month + custom range + chart
        settings/              Business info, policy, currency
    api/                     REST endpoints (see below)
  components/                Shared UI (Header, Footer, BookingFlow, etc.)
  lib/
    db.ts                    SQLite connection + schema (source of truth)
    availability.ts          Scheduling engine + atomic booking transaction
    settings.ts               Key/value settings store
    auth.ts                   Password hashing, JWT sessions, cookies
    i18n.ts                   EN/AR dictionary
    seed.ts                   Demo data
```

### API (all under `/api`)

| Route | Method | Access | Purpose |
|---|---|---|---|
| `/api/services` | GET / POST | public / admin | List active services / create |
| `/api/services/:id` | PATCH | admin | Edit / deactivate |
| `/api/availability` | GET | public | Slot grid for a date + service |
| `/api/appointments` | GET / POST | admin / public | List (filtered) / book |
| `/api/appointments/:id` | PATCH | admin | Edit, reschedule, change status |
| `/api/appointments/:id/cancel` | POST | public (phone-verified) / admin | Cancel |
| `/api/appointments/lookup` | GET | public (rate-limited) | "My Appointment" |
| `/api/business-hours` | GET / PUT | public / admin | Weekly schedule |
| `/api/closures` | GET / POST, `/:id` DELETE | public / admin | Exceptions |
| `/api/announcements` | GET / POST, `/:id` PATCH/DELETE | public / admin | Banner content |
| `/api/settings` | GET / PUT | public (subset) / admin (full) | Business config |
| `/api/shop-status` | GET / PATCH | public / admin | Open/closed toggle |
| `/api/customers` | GET, `/:id` GET | admin | Customer list + history |
| `/api/dashboard/summary` | GET | admin | Today's stat cards |
| `/api/dashboard/revenue` | GET | admin | Revenue by period |
| `/api/auth/login`, `/logout`, `/me` | POST / POST / GET | — | Admin session |

### Core business logic — the scheduling engine

`src/lib/availability.ts` is the source of truth for every scheduling
decision, and it never trusts the client:

- `getSlotsForDate()` builds the full grid of possible start times for a
  date + service, marking each `available` / `booked` / `closed` after
  checking business hours, breaks, closures, and existing confirmed
  appointments.
- `bookAppointment()` re-validates everything server-side and wraps the
  conflict check + insert in a single SQLite transaction
  (`BEGIN IMMEDIATE` … `COMMIT`), so two simultaneous booking requests for
  the same slot cannot both succeed — this was load-tested during
  development by firing two concurrent requests at the same slot; the loser
  correctly receives `409 { error: "slot_taken" }`.

### Security notes

- Passwords hashed with bcrypt (never stored or compared in plaintext).
- Admin sessions are JWTs in an `httpOnly`, `sameSite=lax` cookie —
  inaccessible to client-side JS, `secure` in production.
- Every admin API route re-checks the session server-side
  (`requireAdmin()`); the client-side nav hiding is a UX nicety, not the
  security boundary.
- All inputs are validated with `zod` schemas server-side; nothing about
  price, availability, or appointment status is ever trusted from the client.
- Login and the customer phone-lookup endpoint are rate-limited
  (in-memory — see Known limitations for scaling this past a single process).
- SQL is 100% parameterized (`db.prepare(...).run(...)`) — no string-built
  queries, so no SQL injection surface.

---

## Testing instructions

There's no automated test suite yet (see Known limitations), but here's the
manual checklist this build was verified against — walk through it after any
change:

1. **Customer booking**: `/book` → pick a service → pick a date → pick a
   green slot → enter name/phone → confirm → see the confirmation screen.
2. **Double booking prevention**: open the same date/time in two browser
   tabs (or fire two concurrent `POST /api/appointments`); the second
   confirms it receives `409 slot_taken`.
3. **Cancellation + deadline**: book an appointment, cancel it from
   `/my-appointments` with the matching phone number; then try cancelling an
   appointment inside the configured cancellation window and confirm it's
   blocked with the "can no longer be cancelled" message.
4. **Admin cancellation / reschedule / status changes**: Admin →
   Appointments → Edit / Complete / No-show / Cancel on a row.
5. **Different service durations**: book a 30-min and a 60-min service back
   to back on the same day and confirm slot generation reserves the full
   duration for each (no overlap).
6. **Business hours & breaks**: Admin → Business Hours → add a midday break;
   confirm `/book` no longer offers slots inside it.
7. **Full-day / partial closure**: Admin → Closures → add one; confirm
   `/book` shows no slots (full-day) or skips just that window (partial).
8. **Shop open/closed toggle**: Admin sidebar toggle → confirm the public
   homepage badge flips and `/book` blocks new bookings with the "currently
   unavailable" toast while closed (admin-created bookings still work).
9. **Price change isolation**: change a service's price in Admin → Services;
   confirm already-completed appointments in Revenue keep their original
   price.
10. **Customer history**: Admin → Customers → open a customer → confirm
    totals match their appointment list.
11. **Admin authentication**: log out, confirm every `/admin/*` route
    redirects to `/admin/login`; confirm direct API calls to admin endpoints
    return `401` without a session.
12. **Arabic RTL / English LTR**: use the language switcher in the header;
    confirm layout mirrors correctly and phone numbers/dates stay LTR inside
    RTL text.

---

## Known limitations

Built to be a genuinely working core, not a shallow pass over all 62 spec
sections. What's **not** built yet, so you can plan the next iteration:

- **Database**: SQLite, not Postgres (see Moving to PostgreSQL below).
- **No automated test suite** — only the manual checklist above.
- **No PWA manifest / installable app / offline shell** yet.
- **No in-app/browser push reminders** ("your appointment is in 3 hours") —
  the data needed for this exists (`appointments.date`/`start_time`), but the
  scheduling/permission-handling layer to fire them isn't built. A cron job
  or a `setInterval` check against upcoming appointments, paired with the
  Notification API (with proper permission prompts) or a simple in-site
  banner on return, would be the next step.
- **Single admin account** (email and password can be changed in Admin > Profile).
- **Rate limiting is in-memory**, so it resets on restart and doesn't share
  state across multiple server instances. Fine for a single-process
  deployment; move to Redis (or a platform-level rate limiter) if you scale
  to multiple instances.
- **Price-change confirmation dialog** ("apply to future only" vs. "also
  update selected existing appointments") from the original spec was
  simplified: since every appointment stores its own price snapshot at
  booking time, past records are automatically protected without needing the
  extra dialog — but there's no UI path to *intentionally* bulk-update a set
  of existing appointments' prices if Ahmed ever wanted that.
- **Real shop photos, real logo file, and real Google Maps location** are
  still placeholders per the spec — see sections 15–22 above for how to swap
  them in.
- **Calendar** is a day-view list, not a full week/month grid view yet.
- Automated tests, PWA, and reminders are the natural next milestones.

## Moving to PostgreSQL

The schema and every query in `src/lib/db.ts` and `src/lib/availability.ts`
are plain, parameterized SQL — there's no SQLite-specific syntax beyond a
couple of `PRAGMA` calls and `datetime('now')` defaults (Postgres equivalent:
`now()`). To switch:

1. `npm install pg`
2. Replace `src/lib/db.ts`'s `node:sqlite` connection with a `pg.Pool`
   connected via `DATABASE_URL`.
3. Swap `db.prepare(sql).get/all/run(...)` calls for `pool.query(sql, params)`
   equivalents (or introduce a thin adapter with the same method names so the
   rest of the codebase doesn't change).
4. `INSERT ... ON CONFLICT DO UPDATE` syntax stays the same — it's already
   Postgres-compatible.
5. Replace `datetime('now')` defaults with `now()` in the schema.
6. Once on Postgres, this app becomes deployable to serverless/edge hosts
   too, since it no longer depends on a local file.
