# Re-upload the website to Railway after you changed something.
# Use this AFTER deploy-railway.bat has worked once. No questions to answer.
$ErrorActionPreference = "Continue"
Set-Location $PSScriptRoot

if (-not (Get-Command railway -ErrorAction SilentlyContinue)) {
  Write-Host "Railway tool not found. Run deploy-railway.bat first." -ForegroundColor Red
  Read-Host "Press Enter to close"; exit 1
}

railway whoami 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) { railway login }

# This folder must be linked to your Railway project. If it is a new folder, link it now.
railway status 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) {
  Write-Host "Choose your project (ahmed-cherif-barber) and service (barber-app):" -ForegroundColor Cyan
  railway link
}

railway up --detach
if ($LASTEXITCODE -ne 0) {
  Write-Host "Upload failed. Read the message above." -ForegroundColor Red
  Read-Host "Press Enter to close"; exit 1
}
railway domain
Write-Host "Uploaded. Wait a few minutes, then open the link above." -ForegroundColor Green
Read-Host "Press Enter to close"
