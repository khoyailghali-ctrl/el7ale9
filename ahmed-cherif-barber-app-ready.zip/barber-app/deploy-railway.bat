@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy-railway.ps1"
pause
